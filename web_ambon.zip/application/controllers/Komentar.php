<?php
	class Komentar extends CI_Controller{
    
		public function create($post_id){
			$slug = $this->input->post('slug');
			$data['post'] = $this->article_m->get_posts($slug);

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');

			$this->form_validation->set_rules('body', 'Body', 'required');


			if($this->form_validation->run() === FALSE){
        $this->load->view('_blocks/header');
        $this->load->view('_blocks/nav');
				$this->load->view('kegiatan/view', $data);
				$this->load->view('_blocks/footer');
			} else {
				$this->comment_m->create_comment($post_id);
				redirect('kegiatan/view/'.$slug);
			}
		}
	}