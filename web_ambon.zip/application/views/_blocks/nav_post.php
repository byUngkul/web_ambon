<header>
    <!-- header-area start -->
    <div id="sticker" class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                <!-- Navigation -->
                    <nav class="navbar navbar-default">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <!-- Brand -->
                            <img src="<?=base_url()?>assets/images/logo-ambon.png" width="60px" style="float:left;margin-top:5px">
                            <a class="navbar-brand page-scroll sticky-logo" href="<?= site_url()?>">                                    
                                <h1><span><?=  $kecamatan->nama ?></span> </h1>
                            </a>
                        </div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse main-menu bs-example-navbar-collapse-1" id="navbar-example">                                
                            <ul class="nav navbar-nav navbar-right">
                                  <li class="active"><a class="page-scroll" href="<?= site_url()?>">Beranda</a></li>
                          </ul>
                        </div>
                        <!-- navbar-collapse -->
                    </nav>
                <!-- END: Navigation -->
                </div>
            </div>
        </div>
    </div>
<!-- header-area end -->
</header>
