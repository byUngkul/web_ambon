
        <div id="preloader"></div>     
       
    <!-- header end -->    <!-- Start Slider Area -->
    <div id="beranda" class="slider-area">
        <div class="bend niceties preview-2">
            <div id="ensign-nivoslider" class="slides">
                  <img src="assets/images/slider/slider1.jpg" title="#slider-direction-0"/>
                  <img src="assets/images/slider/slider2.jpg" title="#slider-direction-1"/>
                  <img src="assets/images/slider/slider3.jpg" title="#slider-direction-2"/>
                  <img src="assets/images/slider/slider4.jpg" title="#slider-direction-3"/>
                  <img src="assets/images/slider/slider5.jpg" title="#slider-direction-4"/>
			</div>
			<div id="slider-direction-0" class="slider-direction">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="slider-content">
								<div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
									<h2></h2>
								</div>
								<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
									<h1></h1>
								</div>
								<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>  
			<div id="slider-direction-1" class="slider-direction">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="slider-content">
								<div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
									<h2></h2>
								</div>
								<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
									<h1></h1>
								</div>
								<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
																		</div>
							</div>
						</div>
					</div>
				</div>
			</div>  
			<div id="slider-direction-2" class="slider-direction">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="slider-content">
								<div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
									<h2></h2>
								</div>
								<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
									<h1></h1>
								</div>
								<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
																		</div>
							</div>
						</div>
					</div>
				</div>
			</div>  
			<div id="slider-direction-3" class="slider-direction">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="slider-content">
								<div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
									<h2></h2>
								</div>
								<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
									<h1></h1>
								</div>
								<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
																		</div>
							</div>
						</div>
					</div>
				</div>
			</div>  
			<div id="slider-direction-4" class="slider-direction">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="slider-content">
								<div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
									<h2></h2>
								</div>
								<div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
									<h1></h1>
								</div>
								<div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
																		</div>
							</div>
						</div>
					</div>
				</div>
			</div>  
		</div>
    </div>    <!-- Start Profil area -->
    <div id="profil" class="about-area area-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="section-headline text-center">
                        <h2>Profil</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- single-well start-->                
                <div class="col-md-6 col-sm-6 col-xs-12">                        
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <center><a href="#"><img src="assets/images/camat.jpg" alt=""></a></center>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="venobox vbox-item" data-gall="myGallery" href="assets/images/camat.jpg">
                                        <h4>Camat Teluk Ambon</h4>
                                        <span>Muhamad Nasir Rumata, S.Sos</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <br>
                        <p><center><b><i>Assalammualaikum Wr. Wb.</i></b></center></p>
                        <p><b>DENGAN</b> senang hati dan tangan terbuka kami menyampaikan salam yang hangat bagi Anda untuk mengenal Kecamatan Teluk Ambon Kota Ambon di Propinsi Maluku.</p>
                        <p>Situs ini diharapkan akan memberikan informasi yang cukup mengenai Kecamatan Teluk Ambon Kota Ambon secara umum tentang alamnya, khasanah budaya, masyarakat, pemerintahan, pembangunan, perekonomian serta pariwisata.</p>
                        <p>Pada kesempatan ini saya menghimbau kepada seluruh elemen masyarakat khususnya masyarakat kecamatan Teluk Ambon Kota Ambon, dengan sudah on line nya situs Kecamatan Teluk Ambon Kota Ambon, marilah kita bersama membangun kampung halaman dengan bergotong royong lewat media informasi ini.</p>
                        <p>Saya mengingatkan kepada seluruh masyarakat Kecamatan Teluk Ambon, bahwa faktor penentu keberhasilan program pembangunan adalah dengan memelihara tali silaturrahmi, persatuan dan kesatuan serta menjaga keamanan demi mewujudkan situasi yang kondusif.</p>
                        <p><center><i>Wabillahi Taufik Walhidayah, Wassalammualaikum Wr. Wb.</i></center></p>
                        <p><center>Teluk Ambon , 2019<br>Camat Teluk Ambon</center></p>
                        <br>
                        <p><b><center>Muhamad Nasir Rumata, S.Sos</center></b></p>
                    </div> 
                    <div class="single-awesome-project">
                        <div class="awesome-img">
                            <a href="#"><img src="assets/images/struktur.jpg" alt=""></a>
                            <div class="add-actions text-center">
                                <div class="project-dec">
                                    <a class="venobox vbox-item" data-gall="myGallery" href="assets/images/struktur.jpg">
                                        <h4>Struktur Organisasi</h4>
                                        <span>Kecamatan Teluk Ambon</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <center><h4 class="sec-head">STRUKTUR ORGANISASI</h4></center>                      
                    <div class="team-top">                    
                          <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="single-team-member">
                                    <div class="team-img">
                                        <a href="#"><img src="../assets/images/pegawai/camat.jpg" alt=""></a>
                                        <div class="team-social-icon text-center">
                                            <ul style="padding:0px">
                                                <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                                <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                                <li><a href=""><i class="fa fa-instagram"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="team-content text-center">
                                        <h4>Muhamad Nasir Rumata, S.Sos</h4>
                                        <p>Kepala Camat</p>
                                    </div>
                                </div>
                            </div>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="single-team-member">
                                    <div class="team-img">
                                        <a href="#"><img src="../assets/images/pegawai/camat.jpg" alt=""></a>
                                        <div class="team-social-icon text-center">
                                            <ul style="padding:0px">
                                                <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                                <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                                <li><a href=""><i class="fa fa-instagram"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="team-content text-center">
                                        <h4>Muhamad Nasir Rumata, S.Sos</h4>
                                        <p>Kepala Camat</p>
                                    </div>
                                </div>
                            </div>
                      <!-- End column -->                              
                    </div>   
                    <div class="single-blog">
                        <center><span><a href="pegawai" class="ready-btn" target="_blank">Lihat Pegawai Lainnya</a></span></center>
                    </div>                    
                </div>
                <!-- single-well end-->
                <div class="col-md-6 col-sm-6 col-xs-12" style="border-left:1px solid #ccc;">                    
                    <div class="well-middle">
                        <div class="single-well">                              
                            <center><h4 class="sec-head">Landasan Hukum</h4></center>                                
                            <p>Sesuai dengan Peraturan Daerah Nomor 11 Tahun 2008 tentang Pembentukan Organisasi dan Tata Kerja Kecamatan Kota Ambon.</p>
                            <br>
                            <center><h4 class="sec-head">TUGAS DAN FUNGSI</h4></center>                                                             
                            <h4 class="sec-head">Tugas</h4>                                                                
                            <ul>                            
                                  <li>Membantu Walikota dalam melaksanakan kewenangan pemerintahan yang dilimpahkan untuk menangani sebagian urusan otonomi daerah.</li>
                          </ul>
                            <h4 class="sec-head">Fungsi</h4>                                                                
                            <p>Untuk melaksanakan tugas tersebut, maka Camat mempunyai fungsi adalah :</p>
                            <ul>
                                  <li>Melaksanakan tugas-tugas pemerintahan di kecamatan.</li>
                                  <li>Melaksanakan sebagian kewenangan yang dilimpahkan oleh Walikota.</li>
                          </ul>
                            <br>
                            <center><h4 class="sec-head">VISI & MISI</h4></center>             
                            <h4 class="sec-head">Visi</h4>                                   
                            <p><i><b><center>"TERWUJUDNYA MASYARAKAT SEJAHTERA DAN MANDIRI MELALUI PEMBERDAYAAN DENGAN MENGANDALKAN POTENSI SUMBER DAYA ALAM LOKAL"</center></b></i></p>
                            <h4 class="sec-head">Misi</h4>                                   
                            <ul>
                                  <li>Meningkatkan kemampuan sumber daya aparatur pemerintah Kecamatan sebagai motivator pembangunan dan pelayanan masyarakat.</li>
                                  <li>Meningkatkan serta mendorong peran serta masyarakat untuk memanfaatkan potensi sumber daya yang lebih efektif dan efesien.</li>
                                  <li>Meningkatkan pelayanan prima kepada masyarakat.</li>
                                  <li>Mengfungsikan dan meningkatkan ketersediaan prasarana dan sarana serta fasilitas untuk menunjang tugas-tugas pelayanan publik.</li>
                                  <li>Memberdayakan Lembaga Pemerintah Negeri/Desa dan Lembaga-Lembaga Kemasyarakatan.</li>
                                  <li>Memfungsikan dan meningkatkan peranan pranata sosial masyarakat sebagai kekuatan dalam menggerakkan masyarakat.</li>
                                  <li>Memberdayakan masyarakat serta mengoptimalkan peranan perempuan dan generasi muda.</li>
                                  <li>Mendorong sektor-sektor produksi untuk meningkatkan perekonomian masyarakat.</li>
                                  <li>Mendorong peningkatan kualitas hidup masyarakat.</li>
                                  <li>Mendorong penciptaan peluang sektor swasta untuk mengembangkan Kec. Teluk Ambon dalam upaya pemulihan ekonomi masyarakat.</li>
                          </ul>
                            <br>
                            <center><h4 class="sec-head">KEADAAN GEOGRAFI</h4></center>  
                            <div class="single-awesome-project">
                                <div class="awesome-img">
                                    <a href="#"><img src="assets/images/peta-kecamatan-teluk-ambon.jpg" alt=""></a>
                                    <div class="add-actions text-center">
                                        <div class="project-dec">
                                            <a class="venobox vbox-item" data-gall="myGallery" href="assets/images/peta-kecamatan-teluk-ambon.jpg">
                                                <h4>Peta</h4>
                                                <span>Kecamatan Teluk Ambon</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>                               
                            <p>Letak dan Batas Wilayah Secara Geografi Wilayah Teluk Ambon dibatasi antara lain oleh :
                            <ul>                            
                                  <li>Sebelah Utara : Kec. Leihitu Kab. Maluku Tengah</li>
                                  <li>Sebelah Selatan : Teluk Ambon</li>
                                  <li>Sebelah Barat : Kec. Leihitu Barat Kab. Maluku Tengah</li>
                                  <li>Sebelah Timur : Kec. Teluk Ambon Baguala</li>
                          </ul>  
                            <br>
                            <center><h4 class="sec-head">Luas Wilayah dan Jarak</h4></center> 
                            <p>Sesuai Peraturan Daerah Kota Ambon Nomor 2 Tahun 2006 tentang Pembentukan Kecamatan Leitimur Selatan dan Kecamatan Teluk Ambon, luas keseluruhan wilayah Kecamatan Teluk Ambon adalah 93,68 km2, dengan dua desa terluas adalah Desa Hative Besar seluas 30,00 km2 dan Desa Rumah Tiga seluas 28,39 km2, sedangkan yang terkecil adalah Kelurahan tihu seluas 0,33 km2.</p>
                            <p>Ibukota Kecamatan Teluk Ambon terletak di Desa Wayame, sehingga Desa Laha merupakan desa yang terjauh letaknya dari Ibukota Kecamatan, yaitu sejauh 37,0 Km. </p><br>
                        </div>
                    </div>                    
                </div>
                <!-- End col-->
            </div>            
        </div>
    </div>
    <!-- End Profil area -->    
         
    <div id="kelurahan" class="services-area area-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="section-headline text-center">
                        <h2>Desa dan Negeri / Kelurahan</h2>
                    </div>
                </div>
            </div>
            <div class="row text-center">                
                <div class="services-contents">
                <?php foreach($desas as $desa): ?>
                    <div class="row">
                        <div class="pri_table_list active">                                                                                                           
                            <div class="row">
                                <div class="col-md-3 col-sm-3 col-xs-12" style="margin-top:10px;border-right:1px solid #ccc;">                                        
                                    <a href="negeri-batu-merah"><img src="assets/images/logo-ambon.png" width="100px" alt=""></a>
                                    <h4><?= $desa->nama; ?></h4>
                                    <p><?= $desa->alamat; ?></p>
                                </div>
                                <div class="col-md-9 col-sm-9 col-xs-12" style="padding:10px 40px 10px;text-align:justify">                                        
                                    <?= $desa->profil; ?>
                                </div>
                                <div class="col-md-3 col-sm-4 col-xs-12" style="margin-top:10px">                                                    
                                    <a class="services-icon" href="#"><i class="fa fa-male" style="color:skyblue"></i></a>
                                    <p>Jumlah penduduk Laki-Laki sebanyak<br><strong><?= $desa->jumlah_laki; ?></strong> jiwa</p>                                        
                                </div>                                                
                                <div class="col-md-3 col-sm-4 col-xs-12" style="margin-top:10px">                                                    
                                    <a class="services-icon" href="#"><i class="fa fa-female" style="color:pink"></i></a>
                                    <p>Jumlah penduduk Perempuan sebanyak<br><strong><?= $desa->jumlah_perempuan; ?></strong> jiwa</p>                                                
                                </div>                                                   
                                <div class="col-md-3 col-sm-4 col-xs-12" style="margin-top:10px">                                                    
                                    <a class="services-icon"onclick="window.open('demografi-penduduk', '_blank');">
                                        <i class="fa fa-users" style="color:lightgreen"></i>
                                    </a> <?php $tot_penduduk = $desa->jumlah_laki + $desa->jumlah_perempuan; ?>
                                    <p>Jumlah penduduk sebanyak<br><strong><?= $tot_penduduk; ?></strong> jiwa</p>                                                
                                </div>                                    
                            </div>                                                                                                         
                        </div>                           
                    </div>
                    <br>
                <?php endforeach; ?> 
              </div>
            </div>
        </div>
    </div>
    <!-- End Service area --> 
    <div id="informasi" class="faq-area area-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="section-headline text-center">
                        <h2>Informasi</h2>                                                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="tab-menu">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="active">
                                <a href="#p-view-1" role="tab" data-toggle="tab">Pelayanan Perizinan</a>
                            </li>
                            <li>
                                <a href="#p-view-2" role="tab" data-toggle="tab">Pelayanan Non Perizinan</a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane active" id="p-view-1">
                            <div class="tab-inner" style="margin-top:15px">                                    
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="faq-details">
                                            <div class="panel-group" id="accordion_izin">
                                              <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_izin" href="#izin0">
                                                                    <span class="acc-icons"></span>1. Persyaratan Permohanan IMB                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="izin0" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Keterangan Tanah dan Peta Situasi Tanah Rangkap 3</li>
                                                                      <li>Gambar Konstruksi Bangunan Rangkap 3</li>
                                                                      <li>Kartu Tanda Penduduk ( KTP ) rangkap 3</li>
                                                                      <li>Lunas PBB</li>
                                                                      <li>Perhitungan Struktur Konstruksi Untuk Bangunan Bertingkat</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>20 (dua puluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                              <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_izin" href="#izin1">
                                                                    <span class="acc-icons"></span>2. Persyaratan Permohana SITU                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="izin1" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Permohonan</li>
                                                                      <li>Kartu Tanda Penduduk</li>
                                                                      <li>Photo ukuran 3 X 4 Cm 2 ( Dua ) Buah</li>
                                                                      <li>IPPT IMB</li>
                                                                      <li>Akte Pendiri Perusahaan</li>
                                                                      <li>Lunas PBB</li>
                                                                      <li>Keterangan Tanah Sertifikat/ Kikitir/ Akte Hibah/ Akte Jual Beli</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>15 (lima belas) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                              <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_izin" href="#izin2">
                                                                    <span class="acc-icons"></span>3. Permohonan Pembuat SPPT Baru                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="izin2" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Permohonan</li>
                                                                      <li>Mengisi Surat Pemberitahuan Objek Pajak ( SPOP )</li>
                                                                      <li>Mengisi Surat Kuasa ( Bagi Yang Menguasakan )</li>
                                                                      <li>Photo Copy KTP Pemohon</li>
                                                                      <li>Photo Copy Bukti Kepemilikan Tanah </li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>15 (lima belas) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                              <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_izin" href="#izin3">
                                                                    <span class="acc-icons"></span>4. Persyaratan Mutasi/ Balik Nama SPPT                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="izin3" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Permohonan</li>
                                                                      <li>Mengisi Surat Pemberitahuan Objek Pajak ( SPOP )</li>
                                                                      <li>Mengisi Surat Kuasa ( Bagi Yang Menguasakan )</li>
                                                                      <li>Photo Copy Bukti Kepimilikan Tanah</li>
                                                                      <li>Photo Copy SPPT Tahun Tarakhir</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>15 (lima belas) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                          </div>
                                        </div>
                                    </div>                                            
                                </div>                                         
                            </div>
                        </div>                                
                        <div class="tab-pane" id="p-view-2">
                            <div class="tab-inner" style="margin-top:15px">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="faq-details">
                                            <div class="panel-group" id="accordion_non_izin">
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin0">
                                                                    <span class="acc-icons"></span>1. Persyaratan Membuat Kartu Keluarga (KK)                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin0" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Formulir Pendafataran KK (F5 01 ) yangdiketahui oleh Lurah</li>
                                                                      <li>Formulir Biodata ( F5 02 ) Anggota Keluarga yang diketahui oleh Lurah</li>
                                                                      <li>Pengantar dari RT/RW dan Kelurahan</li>
                                                                      <li>Photo Copy Surat Nikah</li>
                                                                      <li>Photo Copy Akta Kelahiran</li>
                                                                      <li>Photo Copy Ijazah Pendidikan Terakhir</li>
                                                                      <li>Surat Pindah dari Daerah Asal (Bagi Pendatang )</li>
                                                                      <li>Mengisi Formulir F1.01</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin1">
                                                                    <span class="acc-icons"></span>2. Persyaratan Perubahan/ Penamabahan Anggota KK                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin1" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Formulir Permohonan Membuat Kartu Keluarga ( KK )</li>
                                                                      <li>Pengantar Dari RT/RW, Desa/Kelurahan dan Kecamatan</li>
                                                                      <li>Photo Copy Akta Nikah</li>
                                                                      <li>Photo Copy Akta Kelahiran</li>
                                                                      <li>Photo Copy Ijazah Pendidikan Terakhir</li>
                                                                      <li>Surat Pindah Datang</li>
                                                                      <li>Kartu Keluarga Lama ( Asli )</li>
                                                                      <li>Mengisi Formulir F1.01</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin2">
                                                                    <span class="acc-icons"></span>3. Persyaratan Perekaman KTP Elektronik (E-KTP)                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin2" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Formulir Permohonan Membuat Kartu Tanda Penduduk (KTP)</li>
                                                                      <li>Pengantar Dari RT/RW, Desa/Kelurahan</li>
                                                                      <li>KTP lama (ASLI) Untuk Perpanjang KTP</li>
                                                                      <li>Photo Copy KK</li>
                                                                      <li>Photo Copy Akta Kelahiran</li>
                                                                      <li>Photo Copy Ijazah Pendidikan Telakhir</li>
                                                                      <li>Surat Pindah dari Daerah Asal (BAGI PENDATANG)</li>
                                                                      <li>Surat Keterangan Hilang dari Kepolisian (JIKA KARTU KTP HILANG)</li>
                                                                      <li>Mengisi Formulir F1.01</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin3">
                                                                    <span class="acc-icons"></span>4. Persyaratan Pembuat Akta Kelahiran di Bawah 60 hari                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin3" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Keterangan Kelahiran Dari Dokter/Bidan</li>
                                                                      <li>Mengisi Format F2.01 dan F2 .02 Di ketahui Oleh Lurah (SESUAI DOMISILI ORANG TUA)</li>
                                                                      <li>Photo Copy Surat Nikah</li>
                                                                      <li>Photo Copy KTP Orang Tua</li>
                                                                      <li>Photu Copy kartu Keluarga (KK) Berbasis NIK</li>
                                                                      <li>Photo Copy KTP Saksi 2 Orang</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin4">
                                                                    <span class="acc-icons"></span>5. Persyaratan Pembuat Akta Kelahiran di Atas 60 hari                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin4" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Pengantar Dari Kelurahan  (F2.01 DAN F2.02)</li>
                                                                      <li>Photo Copy Surat Nikah</li>
                                                                      <li>Photo Copy KTP</li>
                                                                      <li>Photo Copy Kartu Keluarga (KK) Berbasis  NIK</li>
                                                                      <li>Surat Pernyataan Kesaksian </li>
                                                                      <li>Photo Copy KTP Saksi-Saksi</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin5">
                                                                    <span class="acc-icons"></span>6. Persyaratan Pembuat Surat Keterangan Kematian                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin5" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Pengantar Kematian Dari RT/RW</li>
                                                                      <li>Surat Pengantar Kematian Dari Kelurahan</li>
                                                                      <li>Surat Keterangan Kematian Dari rumah sakit (Bagi Yang Meninggal Di Rumah sakit)</li>
                                                                      <li>Photo Copy KTP Dan kartu Keluarga (KK)</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin6">
                                                                    <span class="acc-icons"></span>7. Persyaratan Pembuat Surat Keterangan Kematian                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin6" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Surat Pengantar dari Lurah</li>
                                                                      <li>Photo Copy KTP Pemohon</li>
                                                                      <li>Surat Pernyataan Tidak Mampu daro Permohon diketahui oleh Lurah</li>
                                                                      <li>Rujukan dari Puskemas bagi yang mau Berobat ke Rumah sakit</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                                          <!-- Panel Default -->
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="check-title">
                                                                <a data-toggle="collapse" data-parent="#accordion_non_izin" href="#nonizin7">
                                                                    <span class="acc-icons"></span>8. Register SKCK (Surat Ket. Catatan Kepolisian)                                                                </a>
                                                            </h4>
                                                        </div>
                                                        <div id="nonizin7" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                                <h4 class="check-title">Persyaratan Pelayanan :</h4>
                                                                <ol>
                                                                      <li>Fotokopi Kartu Tanda Penduduk (KTP) atau Surat Izin Mengemudi (SIM).</li>
                                                                      <li>Fotokopi Kartu Keluarga (KK).</li>
                                                                      <li>Fotokopi Akta Kelahiran/Surat Kenal Lahir/Ijazah Terakhir.Pas foto 4x6 berlatar/background merah sebanyak 6 lembar</li>
                                                              </ol>
                                                                <br>    
                                                                  <h4 class="check-title">Jangka Waktu Penyelesaian : <b>10 (sepuluh) menit</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Keterangan : <b>JIKA PERSYARATAN LENGKAP</b></h4>               
                                                                    <br>
                                                                  <h4 class="check-title">Biaya / Tarif : <b>TIDAK ADA BIAYA / GRATIS</b></h4>               
                                                                    <br>
                                                          </div>
                                                        </div>
                                                    </div>
                                          </div>
                                        </div>
                                    </div>                                            
                                </div>                                    
                            </div>
                        </div>                                                            
                    </div>
                </div>                                                        
            </div>
        </div>
    </div>
    <div id="berita" class="blog-area">
        <div class="blog-inner area-padding">
            <div class="blog-overly"></div>
            <div class="container ">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="section-headline text-center">
                            <h2>Kegiatan</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                <?php 
                    foreach($kegiatan as $post) :
                        $create_at = date("d-M-Y", strtotime($post->created_at));
                ?>
                      <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="single-blog">
                                <div class="single-blog-img">
                                    <a href="<?= site_url('/kegiatan/view/'.$post->slug) ?>">
                                        <img src="<?= site_url('assets/images/articles/'.$post->post_image); ?>" alt="">
                                    </a>
                                </div>
                                <div class="blog-meta">
                                    <span class="comments-type">
                                        <i class="fa fa-comment-o"></i>
                                        <a href="#">0 komentar</a>
                                    </span>
                                    <span class="date-type"><i class="fa fa-calendar"></i><?= $create_at ?></span>
                                </div>
                                <div class="blog-text">
                                    <h4><a href="<?= site_url('/kegiatan/view/'.$post->slug) ?>"><?= $post->title?></a></h4>
                                    <p style="text-align:justify"><?= word_limiter($post->body, 35) ?><a href="#">...baca Selengkapnya</a></p>
                                </div>                                
                            </div>
                        </div>          
                <?php endforeach; ?>     
                  <div class="single-blog">
                        <center><span><a href="<?php echo base_url();?>kegiatan/" class="ready-btn">Kegiatan Selengkapnya</a></span></center>
                    </div>
                </div>
            </div>                <!-- End Right Blog-->
        </div>
    </div>  
    
    <div id="potensi" class="blog-area">
        <div class="blog-inner area-padding">
            <div class="blog-overly"></div>
            <div class="container ">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="section-headline text-center">
                            <h2>Potensi</h2>
                        </div>
                    </div>
                </div>
                <div class="row">			
                <?php 
                    foreach($potensi as $post) :
                        $create_at = date("d-M-Y", strtotime($post->created_at));
                ?>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="single-blog">
                            <div class="single-blog-img">
                                <a href="<?= site_url('/kegiatan/view/'.$post->slug) ?>">
                                    <img src="<?= site_url('assets/images/articles/'.$post->post_image); ?>" alt="">
                                </a>
                            </div>
                            <div class="blog-meta">
                                <span class="comments-type">
                                    <i class="fa fa-comment-o"></i>
                                    <a href="#">0 komentar</a>
                                </span>
                                <span class="date-type"><i class="fa fa-calendar"></i><?= $create_at ?></span>
                            </div>
                            <div class="blog-text">
                                <h4><a href="<?php echo site_url('/kegiatan/view/'.$post->slug); ?>"><?= $post->title; ?></a></h4>
                                <p style="text-align:justify"><?= $post->body ?><a href="<?php echo site_url('/kegiatan/view/'.$post->slug); ?>">...baca Selengkapnya</a></p>
                            </div>                                
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
                <div class="single-blog">
                        <center><span><a href="<?php echo base_url();?>kegiatan/index_potensi" class="ready-btn">Potensi Selengkapnya</a></span></center>
                </div>                
            </div>                <!-- End Right Blog-->
        </div>
    </div>            
    
    <!-- Start portfolio Area -->
    <div id="portfolio" class="portfolio-area area-padding fix">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="section-headline text-center">
                        <h2>Gallery</h2>
                    </div>
                </div>
            </div>
            <div class="row">
            <!-- Start Portfolio -page -->                
                <div class="awesome-project-content">
                <!-- single-awesome-project start -->
                <?php foreach($gallery as $row): ?>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="single-awesome-project">
                            <div class="awesome-img">
                                <a href="<?= site_url('assets/images/galleri/'.$row->image) ?>"><img src="<?= site_url('assets/images/galleri/'.$row->image) ?>" alt="" /></a>
                                <div class="add-actions text-center">
                                    <div class="project-dec">
                                        <a class="venobox" data-gall="myGallery" href="<?= site_url('assets/images/galleri/'.$row->image) ?>">
                                            <h4><?= $row->nama ?></h4>
                                            <span><?= $row->keterangan ?></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                              
                <?php endforeach; ?>    
                </div>                
                <div class="single-blog">
                    <center><span><a href="gallery" class="ready-btn">Gallery Selengkapnya</a></span></center>
                </div>            
            </div>
          <!-- single-awesome-project end -->
        </div>
    </div>    
    <!-- awesome-portfolio end -->        
    <div id="kontak" class="contact-area">
        <div class="contact-inner area-padding">
            <div class="contact-overly"></div>
            <div class="container ">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="section-headline text-center">
                            <h2>Kontak</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- Start contact icon column -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="contact-icon text-center">
                            <div class="single-icon">
                                <i class="fa fa-mobile"></i>
                                <p>
                                    Telepon : <?= $kecamatan->telp ?> / <?= $kecamatan->telp2 ?><br>
                                    <span>Senin s/d Jumat 08.00 - 15.00 WITA.</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Start contact icon column -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="contact-icon text-center">
                            <div class="single-icon">
                                <i class="fa fa-envelope-o"></i>
                                <p>
                                    Email : <a href="mailto:<?= $kecamatan->email ?>" target="_top"><?= $kecamatan->email ?></a><br>
                                </p>
                            </div>
                        </div>
                    </div>
                     <!-- Start contact icon column -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="contact-icon text-center">
                            <div class="single-icon">
                                <i class="fa fa-map-marker"></i>
                                <p>
                                    Lokasi Kantor: <br>
                                    <span><?= $kecamatan->alamat_kantor ?></span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- Start Google Map -->
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div id="googleMap" style="width:100%;height:400px;"></div>
                        <script>
                            function myMap() 
                            {
                                var mapProp= 
                                {
                                    center:new google.maps.LatLng(-3.694986,128.1869601),
                                    zoom:15,
                                };
                                var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
                            }
                        </script>                
                        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_6U38bgntYFEIIF9umRIhHRh4Rd1s4h4&callback=myMap"></script>                               
                    </div>
                    <!-- End Google Map -->
                    <!-- Start  contact -->
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form contact-form">
                            <div id="sendmessage">Your message has been sent. Thank you!</div>
                            <div id="errormessage"></div>
                            <form action="" method="post" role="form" class="contactForm">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Nama" data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Email" data-rule="email" data-msg="Please enter a valid email">
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Pesan" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject">
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Ketik yang ingin disampaikan disini" placeholder="Ketik pesan disini"></textarea>
                                    <div class="validation"></div>
                                </div>
                                <div class="text-center"><button type="submit">Kirim Pesan</button></div>
                            </form>
                        </div>
                    </div>
                    <!-- End Left contact -->
                </div>
            </div>
        </div>
    </div>
    