<!-- Bootstrap core JavaScript-->
<script src="<?= base_url()?>assets/backend/vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url()?>assets/backend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?= base_url()?>assets/backend/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="<?= base_url()?>assets/backend/vendor/datatables/jquery.dataTables.js"></script>
  <script src="<?= base_url()?>assets/backend/vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?= base_url()?>assets/backend/js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="<?= base_url()?>assets/backend/js/demo/datatables-demo.js"></script>

  <!-- plugin jquery chained -->
  <script src="<?= base_url()?>assets/backend/js/demo/jquery.chained.js"></script>