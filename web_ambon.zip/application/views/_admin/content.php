<h1>Welcome to admin page.</h1>
<hr>
<p>Anda masuk sebagai <strong><?= $this->session->userdata('name') ?></strong>.</p>