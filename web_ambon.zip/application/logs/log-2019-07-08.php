<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-08 19:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-08 19:45:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 19:45:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 19:45:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-08 19:59:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 19:59:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 19:59:51 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-08 20:02:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:02:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:02:38 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-08 20:03:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-08 20:06:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-08 20:07:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:07:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:07:03 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-08 20:13:32 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 4
ERROR - 2019-07-08 20:13:32 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 4
ERROR - 2019-07-08 20:13:32 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 4
ERROR - 2019-07-08 20:13:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:13:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:13:32 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-08 20:14:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:14:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:14:31 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-08 20:16:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:16:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:16:33 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-08 20:17:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:17:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:25:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:25:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:26:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:26:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:26:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:26:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:27:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-08 20:27:08 --> 404 Page Not Found: Assets/backend
