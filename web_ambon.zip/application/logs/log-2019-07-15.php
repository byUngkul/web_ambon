<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-15 05:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-15 05:00:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-15 05:01:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 05:01:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 05:03:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 05:03:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 05:03:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 05:03:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 05:03:10 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-15 06:08:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 06:08:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 06:08:51 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-15 09:31:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-15 09:31:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:31:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:31:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:31:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:31:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:31:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:31:57 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-15 09:32:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:32:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:32:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:32:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:32:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:32:33 --> 404 Page Not Found: admin/Potensi/assets
ERROR - 2019-07-15 09:32:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:32:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:33:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:33:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:34:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:59:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:59:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:59:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 09:59:22 --> 404 Page Not Found: admin/Desa/assets
ERROR - 2019-07-15 10:00:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:00:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:01:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:04:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:05:02 --> Severity: Notice --> Undefined property: stdClass::$alamat_kantor D:\xampp\htdocs\web_ambon\application\views\_admin\desa\edit.php 21
ERROR - 2019-07-15 10:05:03 --> Severity: Notice --> Undefined property: stdClass::$telp D:\xampp\htdocs\web_ambon\application\views\_admin\desa\edit.php 28
ERROR - 2019-07-15 10:05:03 --> Severity: Notice --> Undefined property: stdClass::$telp2 D:\xampp\htdocs\web_ambon\application\views\_admin\desa\edit.php 35
ERROR - 2019-07-15 10:05:03 --> Severity: Notice --> Undefined property: stdClass::$logo D:\xampp\htdocs\web_ambon\application\views\_admin\desa\edit.php 56
ERROR - 2019-07-15 10:05:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:05:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:05:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:05:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:23:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:26:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:26:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:26:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:26:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:26:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:26:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:27:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:27:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:27:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:27:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:29:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 10:55:24 --> 404 Page Not Found: Negeri-batu-merah/index
ERROR - 2019-07-15 10:57:04 --> 404 Page Not Found: Negeri-galala/index
ERROR - 2019-07-15 11:00:36 --> 404 Page Not Found: Negeri-galala/index
ERROR - 2019-07-15 11:12:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 11:12:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 11:12:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 11:12:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 11:12:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 14:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-15 14:41:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-15 14:41:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 14:41:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 14:41:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 14:41:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 14:41:58 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-15 14:42:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 14:42:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 14:42:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:09:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:11:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 122
ERROR - 2019-07-15 15:11:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:11:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:27:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:27:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:27:27 --> Query error: Unknown column 'kl.tl_id' in 'on clause' - Invalid query: SELECT *
FROM `kependudukan_kl` `kl`
JOIN `kependudukan_vl` `vl` ON `vl`.`kl_id` = `kl`.`id`
JOIN `kependudukan_tl` `tl` ON `tl`.`tl_id` = `kl`.`tl_id`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `tl`.`tl_key`
ORDER BY `vl`.`id` ASC
ERROR - 2019-07-15 15:28:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:28:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:32:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:32:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:40:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:40:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:47:11 --> Severity: Notice --> Undefined index: lkai D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 104
ERROR - 2019-07-15 15:47:12 --> Severity: Notice --> Undefined index: lkai D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 104
ERROR - 2019-07-15 15:47:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:48:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:50:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:51:27 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 106
ERROR - 2019-07-15 15:51:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:51:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:52:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:52:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:52:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:53:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 15:56:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 16:01:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 16:02:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 16:06:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 16:59:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 16:59:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 17:01:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 17:01:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-15 17:03:06 --> 404 Page Not Found: Assets/backend
