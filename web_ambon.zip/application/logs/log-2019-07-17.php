<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-17 01:30:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 01:30:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 01:30:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 03:40:48 --> Query error: Unknown column 'kl.kl_key' in 'field list' - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`kl_key`, `kl`.`kl_text`, sum(kl.laki) as l, sum(kl.perempuan) as p, sum(kl.total) as tot
FROM `kependudukan_kl` `kl`
JOIN `kependudukan_tl` `tl` ON `tl`.`tl_key` = `kl`.`tl_key`
WHERE `kl`.`tl_key` = 'penduduk'
GROUP BY `kl`.`kl_text`
ERROR - 2019-07-17 03:41:23 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 52
ERROR - 2019-07-17 03:42:56 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 52
ERROR - 2019-07-17 03:43:04 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 52
ERROR - 2019-07-17 03:57:52 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 52
ERROR - 2019-07-17 03:59:48 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 54
ERROR - 2019-07-17 04:00:19 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 54
ERROR - 2019-07-17 04:01:21 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 54
ERROR - 2019-07-17 04:01:32 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 54
ERROR - 2019-07-17 04:01:52 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 54
ERROR - 2019-07-17 04:01:55 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\views\_blocks\desa.php 54
ERROR - 2019-07-17 05:11:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:26:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:26:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:28:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:29:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:30:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:31:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:32:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:38:55 --> Query error: Table 'web_ambon.kependudkan_kl' doesn't exist - Invalid query: SELECT `laki`
FROM `kependudkan_kl`
WHERE `tl_key` = 'penduduk'
ERROR - 2019-07-17 05:39:04 --> Query error: Table 'web_ambon.kependudkan_kl' doesn't exist - Invalid query: SELECT `laki`
FROM `kependudkan_kl`
WHERE `tl_key` = 'penduduk'
ERROR - 2019-07-17 05:39:35 --> Severity: Warning --> mysqli_num_rows() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 103
ERROR - 2019-07-17 05:39:38 --> Severity: Warning --> mysqli_num_rows() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 103
ERROR - 2019-07-17 05:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:44:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:45:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 104
ERROR - 2019-07-17 05:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:45:36 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 104
ERROR - 2019-07-17 05:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 05:56:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 105
ERROR - 2019-07-17 05:56:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 105
ERROR - 2019-07-17 05:56:53 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 105
ERROR - 2019-07-17 05:57:58 --> Severity: Parsing Error --> syntax error, unexpected '","' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 105
ERROR - 2019-07-17 05:58:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:15:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:16:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:18:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:21:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:22:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:24:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:25:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:26:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:26:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:27:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:27:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:28:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:28:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:33:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:33:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:35:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:38:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:40:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:40:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:40:24 --> Severity: Notice --> Undefined variable: param D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 94
ERROR - 2019-07-17 06:41:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:41:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:41:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:42:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:42:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:43:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:43:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:43:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:43:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:43:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:49:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:51:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:51:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:52:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 06:54:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:55:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:57:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 06:57:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 07:56:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 07:56:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 07:59:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:24:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:25:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:30:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:30:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:30:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:30:33 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-17 08:31:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:32:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:32:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:32:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:32:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:32:10 --> 404 Page Not Found: admin/Users/assets
ERROR - 2019-07-17 08:32:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:32:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:33:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:33:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:33:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:33:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:34:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:34:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:34:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:34:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:34:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 08:37:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:40:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:40:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:41:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:41:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:42:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:43:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:45:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:46:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:47:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:53:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 08:54:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 09:01:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:01:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:01:48 --> 404 Page Not Found: admin/Potensi/assets
ERROR - 2019-07-17 09:05:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 09:06:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 09:12:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 09:16:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 09:18:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 09:47:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:47:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:47:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:47:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:48:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:48:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:49:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:49:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:49:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 09:58:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:08:12 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 335
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:17 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:18 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:19 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:13:20 --> Severity: Notice --> Undefined property: stdClass::$jenis_infra D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 352
ERROR - 2019-07-17 10:16:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:18:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:18:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:42 --> Severity: Notice --> Undefined property: stdClass::$value D:\xampp\htdocs\web_ambon\application\views\_blocks\footer.php 334
ERROR - 2019-07-17 10:24:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:26:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:27:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:29:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:30:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:34:24 --> 404 Page Not Found: 
ERROR - 2019-07-17 10:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:34:24 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 10:49:28 --> Severity: Parsing Error --> syntax error, unexpected '$route' (T_VARIABLE) D:\xampp\htdocs\web_ambon\application\config\routes.php 55
ERROR - 2019-07-17 10:49:50 --> 404 Page Not Found: 
ERROR - 2019-07-17 10:49:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:49:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 10:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 10:51:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 10:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:51:50 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 10:51:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 10:55:09 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 5
ERROR - 2019-07-17 10:55:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 5
ERROR - 2019-07-17 10:55:09 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 10:55:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 10:55:09 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 10:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 10:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 10:55:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 10:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 5
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 5
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:01:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:01:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:01:17 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 8
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 8
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:02:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:02:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:04:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:04:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:04:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:04:44 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:04:44 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:04:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:06:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:06:39 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:06:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:07:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:07:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:07:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:07:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:08:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:08:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:08:00 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:08:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:08:01 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:08:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:08:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:09:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:10:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 11:10:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 11:10:02 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:10:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:10:02 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:10:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:10:03 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:03 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:03 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:03 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:03 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:03 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:10:05 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:10 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:10 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:11 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:15 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:15 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:16 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:20 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:20 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:21 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:25 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:25 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:26 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:30 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:30 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:31 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:35 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:35 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:36 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:40 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:40 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:42 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:45 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:45 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:47 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:50 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:50 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:51 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:55 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:55 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:10:56 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:00 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:00 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:01 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:05 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:05 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:06 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:10 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:10 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:12 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:15 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:15 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:18 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:20 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:20 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:21 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:25 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:25 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:27 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:30 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:30 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-17 11:11:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:11:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:11:44 --> 404 Page Not Found: Negeri-galala/index
ERROR - 2019-07-17 11:12:11 --> 404 Page Not Found: Negeri-galala/index
ERROR - 2019-07-17 11:12:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:13:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:13:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:13:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:13:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:13:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:14:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:15:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:16:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:17:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:18:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:18:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:18:04 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) D:\xampp\htdocs\web_ambon\application\controllers\Csite.php 9
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:21:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Undefined variable: kegiatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:21:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 141
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 194
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 206
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:21:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 218
ERROR - 2019-07-17 11:21:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:21:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:21:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:22:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:23:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:24:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Use of undefined constant posts - assumed 'posts' D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 224
ERROR - 2019-07-17 11:24:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 224
ERROR - 2019-07-17 11:24:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:24:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:24:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Use of undefined constant posts - assumed 'posts' D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 224
ERROR - 2019-07-17 11:24:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 224
ERROR - 2019-07-17 11:24:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:24:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:24:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 200
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 212
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 224
ERROR - 2019-07-17 11:24:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 224
ERROR - 2019-07-17 11:25:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:25:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:25:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:04 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:26:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:26:04 --> Severity: Notice --> Undefined variable: pemerintahan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:26:04 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:26:04 --> Query error: Column 'desa_id' in where clause is ambiguous - Invalid query: SELECT `posts`.*, `desa`.`desa_id`, `desa`.`nama` as `nama_desa`, `desa`.`slug` as `slug_ds`
FROM `posts`
JOIN `categories` ON `categories`.`id` = `posts`.`category_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `desa_id` IS NULL
ORDER BY `posts`.`id` DESC
ERROR - 2019-07-17 11:26:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:26:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:16 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:27:16 --> Query error: Column 'desa_id' in where clause is ambiguous - Invalid query: SELECT `posts`.*, `desa`.`desa_id`, `desa`.`nama` as `nama_desa`, `desa`.`slug` as `slug_ds`
FROM `posts`
JOIN `categories` ON `categories`.`id` = `posts`.`category_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `desa_id` = '2'
ORDER BY `posts`.`id` DESC
ERROR - 2019-07-17 11:27:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:37 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:27:37 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:27:37 --> Query error: Column 'desa_id' in where clause is ambiguous - Invalid query: SELECT `posts`.*, `desa`.`desa_id`, `desa`.`nama` as `nama_desa`, `desa`.`slug` as `slug_ds`
FROM `posts`
JOIN `categories` ON `categories`.`id` = `posts`.`category_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `desa_id` IS NULL
ORDER BY `posts`.`id` DESC
ERROR - 2019-07-17 11:27:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:27:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:28:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:28:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:28:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:28:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:45 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:28:46 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:28:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:28:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:28:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:02 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:02 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:29:02 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:02 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:03 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:29:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:29:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:08 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:08 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:29:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:29:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:29:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:34 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:29:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:29:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:29:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:30:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:30:02 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:30:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:30:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:30:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:30:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:30:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:30:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:31:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:31:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:31:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:31:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:31:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:32:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:32:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:32:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:32:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:35 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:33:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:33:35 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 145
ERROR - 2019-07-17 11:33:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:33:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:33:35 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:33:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 201
ERROR - 2019-07-17 11:33:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:33:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:33:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:33:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 213
ERROR - 2019-07-17 11:33:36 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:33:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 225
ERROR - 2019-07-17 11:33:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:33:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:33:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:34:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:34:14 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:34:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:34:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:34:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:34:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:35:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:35:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:35:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:35:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:35:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:35:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:35:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:35:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:35:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:35:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:43 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:36:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:36:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:36:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:36:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:36:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 11:36:43 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:36:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 11:36:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:36:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:36:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:11 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:37:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:37:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:37:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:37:43 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:37:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:37:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:37:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:37:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:38:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:39:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:40:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:35 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:40 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:50 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:55 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:41:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:05 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:10 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:20 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:25 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:42:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:42:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:42:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:30 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:42:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:45 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:42:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:42:58 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:42:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:42:58 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:42:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:42:58 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:42:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:42:58 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:42:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:42:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:42:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:00 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:43:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:43:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:44:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:44:20 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:44:21 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:44:21 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:44:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:44:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:44:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:44:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:44:38 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:44:39 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:44:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:44:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:44:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:29 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:45:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:46:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:47:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:48:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:49:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:12 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:50:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:51:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:52:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:04 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:37 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:53:57 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:09 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:17 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:32 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:54:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:19 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:22 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:27 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:36 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:41 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:46 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:47 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:52 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:55:59 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:02 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:07 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:56:10 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:56:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:56:11 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:56:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:56:11 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:56:11 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:56:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:56:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:26 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:31 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:33 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:34 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:49 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:54 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:56:58 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:01 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:16 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:18 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:21 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:24 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:28 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:39 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:44 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:48 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:51 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:57:53 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:03 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:06 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:08 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:11 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:58:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:58:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:58:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:58:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:15 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 11:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 11:58:44 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 51
ERROR - 2019-07-17 11:58:44 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 11:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:00:42 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:00:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:00:43 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 12:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:00:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:01:05 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:01:12 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:01:13 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:01:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:01:14 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 12:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:02:55 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:02:55 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:02:55 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:02:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:02:55 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Undefined variable: pemeintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:02:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:02:56 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 12:02:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:04:42 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 12:04:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:08:13 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 12:08:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:09:38 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 12:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:24:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:24:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:29:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:29:50 --> 404 Page Not Found: Ciste/index
ERROR - 2019-07-17 12:31:13 --> 404 Page Not Found: Ciste/index
ERROR - 2019-07-17 12:31:18 --> 404 Page Not Found: Ciste/index
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav.php 20
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 2
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\desa.php 46
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\desa.php 98
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\desa.php 150
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\potensi_infra.php 43
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\potensi_infra.php 43
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\potensi_infra.php 43
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 205
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 217
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\home.php 229
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:31:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:31:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:31:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:31:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:32:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:32:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:32:46 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:32:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:32:46 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:32:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:32:46 --> 404 Page Not Found: 
ERROR - 2019-07-17 12:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:32:46 --> 404 Page Not Found: Csite/assets
ERROR - 2019-07-17 12:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:33:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:33:25 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:33:25 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:33:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:33:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:33:27 --> 404 Page Not Found: 
ERROR - 2019-07-17 12:33:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 26
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:35:29 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:35:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:35:30 --> 404 Page Not Found: 
ERROR - 2019-07-17 12:35:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:35:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:36:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 26
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:36:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:36:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:37:37 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:37:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:44:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:53:53 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\web_ambon\application\controllers\Csite.php 46
ERROR - 2019-07-17 12:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 26
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:56:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:56:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:56:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:56:23 --> 404 Page Not Found: Pemerintahan/assets
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:56:47 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:56:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:56:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:57:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:57:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:58:44 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:58:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:58:44 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 20
ERROR - 2019-07-17 12:58:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 20
ERROR - 2019-07-17 12:58:44 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:58:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:58:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:59:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 12:59:49 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 20
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 20
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 13:00:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\header.php 6
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 20
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\nav_post.php 20
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 102
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 118
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 134
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 154
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 179
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 195
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 211
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 231
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 256
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 273
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 290
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 311
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Undefined variable: pemerintah D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 13:00:12 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_csite\footer.php 337
ERROR - 2019-07-17 13:00:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 13:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 13:01:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 13:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 13:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 13:04:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-17 15:11:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:11:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:15:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:15:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:20:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:20:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:20:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:20:20 --> 404 Page Not Found: Users/edit
ERROR - 2019-07-17 15:20:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:20:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:21:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:21:47 --> 404 Page Not Found: Users/edit
ERROR - 2019-07-17 15:22:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:22:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:23:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:23:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:24:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:24:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:24:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:26:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:28:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:28:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:28:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:29:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:30:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:34:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:34:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:34:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:35:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:35:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:35:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:37:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:39:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:39:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:39:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:41:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\xampp\htdocs\web_ambon\application\views\_admin\user\edit.php 71
ERROR - 2019-07-17 15:41:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:42:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:46:05 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\web_ambon\application\controllers\admin\Main.php 26
ERROR - 2019-07-17 15:46:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\web_ambon\application\controllers\admin\Main.php 26
ERROR - 2019-07-17 15:46:35 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\web_ambon\application\controllers\admin\Main.php 26
ERROR - 2019-07-17 15:48:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:48:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:48:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:48:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:49:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:49:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:49:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:50:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:50:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:53:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:54:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:54:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:57:39 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 15:58:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:59:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:59:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 15:59:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 115
ERROR - 2019-07-17 16:00:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:01:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:01:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:11:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:16:41 --> Severity: Compile Error --> Cannot redeclare Penduduk_m::update_jkteg() D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 131
ERROR - 2019-07-17 16:24:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:24:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:24:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:32:38 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:32:49 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:32:52 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:33:09 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:33:16 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:33:22 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:33:22 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:34:07 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:34:18 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:34:21 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:34:25 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 139
ERROR - 2019-07-17 16:34:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 141
ERROR - 2019-07-17 16:35:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:35:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:35:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:35:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:37:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:37:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-17 16:37:53 --> 404 Page Not Found: Assets/css
