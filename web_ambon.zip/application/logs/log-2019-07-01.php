<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-01 09:05:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-01 09:05:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:05:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:06:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:06:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:18:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:18:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:20:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:20:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:20:22 --> 404 Page Not Found: admin/Penduduk/edit
ERROR - 2019-07-01 09:20:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-01 09:20:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:20:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:20:45 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-01 09:21:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:21:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:21:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:21:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:37:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:37:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:38:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 09:38:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:02:09 --> Severity: Notice --> Undefined property: Penduduk::$penduduk_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:02:09 --> Severity: Error --> Call to a member function getPendidikan() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:03:20 --> Severity: Notice --> Undefined property: Penduduk::$penduduk_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:03:20 --> Severity: Error --> Call to a member function getPendidikan() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:06:15 --> Severity: Notice --> Undefined property: Penduduk::$penduduk_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:06:15 --> Severity: Error --> Call to a member function getPendidikan() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:06:45 --> Severity: Notice --> Undefined property: Penduduk::$penduduk_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:06:45 --> Severity: Error --> Call to a member function getPendidikan() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:08:51 --> Severity: Notice --> Undefined property: Penduduk::$penduduk_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:08:51 --> Severity: Error --> Call to a member function getPendidikan() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:09:17 --> Severity: Notice --> Undefined property: Penduduk::$penduduk_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:09:17 --> Severity: Error --> Call to a member function getPendidikan() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 26
ERROR - 2019-07-01 10:09:56 --> Query error: Column 'id_desa' in where clause is ambiguous - Invalid query: SELECT `kependudukan_tl`.`tl_text`
FROM `kependudukan_vl`
LEFT JOIN `kependudukan_kl` ON `kependudukan_kl`.`id` = `kependudukan_vl`.`kl_id`
LEFT JOIN `kependudukan_tl` ON `kependudukan_tl`.`tl_id` = `kependudukan_vl`.`id`
WHERE `id_desa` = '5'
ERROR - 2019-07-01 10:11:28 --> Query error: Unknown column 'kependuduka_tl.id_desa' in 'where clause' - Invalid query: SELECT `kependudukan_tl`.`tl_text`
FROM `kependudukan_vl`
LEFT JOIN `kependudukan_kl` ON `kependudukan_kl`.`id` = `kependudukan_vl`.`kl_id`
LEFT JOIN `kependudukan_tl` ON `kependudukan_tl`.`tl_id` = `kependudukan_vl`.`id`
WHERE `kependuduka_tl`.`id_desa` = '5'
ERROR - 2019-07-01 10:11:49 --> Query error: Unknown column 'kependuduka_tl.id_desa' in 'where clause' - Invalid query: SELECT `kependudukan_tl`.`tl_text`
FROM `kependudukan_vl`
LEFT JOIN `kependudukan_kl` ON `kependudukan_kl`.`id` = `kependudukan_vl`.`kl_id`
LEFT JOIN `kependudukan_tl` ON `kependudukan_tl`.`tl_id` = `kependudukan_vl`.`id`
WHERE `kependuduka_tl`.`id_desa` = '5'
ERROR - 2019-07-01 10:14:20 --> Query error: Unknown column 'kependuduka_tl.id_desa' in 'where clause' - Invalid query: SELECT `kependudukan_tl`.`tl_text`
FROM `kependudukan_vl`
LEFT JOIN `kependudukan_kl` ON `kependudukan_kl`.`id` = `kependudukan_vl`.`kl_id`
LEFT JOIN `kependudukan_tl` ON `kependudukan_tl`.`tl_id` = `kependudukan_vl`.`id`
WHERE `kependuduka_tl`.`id_desa` = '5'
ERROR - 2019-07-01 10:15:35 --> Query error: Unknown column 'kependuduka_tl.id_desa' in 'where clause' - Invalid query: SELECT `kependudukan_tl`.`tl_text`
FROM `kependudukan_vl`
LEFT JOIN `kependudukan_kl` ON `kependudukan_kl`.`id` = `kependudukan_vl`.`kl_id`
LEFT JOIN `kependudukan_tl` ON `kependudukan_tl`.`tl_id` = `kependudukan_vl`.`tl_id`
WHERE `kependuduka_tl`.`id_desa` = '5'
ERROR - 2019-07-01 10:16:45 --> Query error: Unknown column 'kependuduka_tl.id_desa' in 'where clause' - Invalid query: SELECT `kependudukan_tl`.`tl_text`
FROM `kependudukan_vl`
JOIN `kependudukan_kl` ON `kependudukan_kl`.`id` = `kependudukan_vl`.`kl_id`
JOIN `kependudukan_tl` ON `kependudukan_tl`.`tl_id` = `kependudukan_vl`.`tl_id`
WHERE `kependuduka_tl`.`id_desa` = '5'
ERROR - 2019-07-01 10:19:01 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 33
ERROR - 2019-07-01 10:20:44 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 33
ERROR - 2019-07-01 10:21:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:21:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:21:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:21:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:21:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:21:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:22:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:22:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:24:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:24:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:24:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:24:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 24
ERROR - 2019-07-01 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 25
ERROR - 2019-07-01 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 24
ERROR - 2019-07-01 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 25
ERROR - 2019-07-01 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 24
ERROR - 2019-07-01 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 25
ERROR - 2019-07-01 10:24:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:25:48 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 41
ERROR - 2019-07-01 10:26:43 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 28
ERROR - 2019-07-01 10:53:21 --> Severity: Notice --> Undefined property: stdClass::$tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 24
ERROR - 2019-07-01 10:53:21 --> Severity: Notice --> Undefined property: stdClass::$tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 24
ERROR - 2019-07-01 10:53:21 --> Severity: Notice --> Undefined property: stdClass::$tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 24
ERROR - 2019-07-01 10:53:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:53:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 10:53:21 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-01 11:02:33 --> Severity: Notice --> Undefined property: stdClass::$kl_value D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-01 11:02:33 --> Severity: Notice --> Undefined property: stdClass::$kl_value D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-01 11:02:33 --> Severity: Notice --> Undefined property: stdClass::$kl_value D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-01 11:02:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:02:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:02:33 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-01 11:03:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:03:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:03:29 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-01 11:12:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:12:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:12:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:12:47 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-01 11:34:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:34:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:36:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:36:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:43:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:43:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:48:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:50:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-01 11:50:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:50:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:50:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:50:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:50:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:50:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:51:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:51:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:51:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:51:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:57:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:57:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:57:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:57:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:57:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:57:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:57:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:58:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 11:58:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 12:00:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 12:00:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 12:00:31 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-01 12:02:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 12:02:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 12:02:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 12:02:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 12:02:06 --> 404 Page Not Found: admin/Users/assets
ERROR - 2019-07-01 17:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-01 17:41:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-01 17:41:55 --> Unable to connect to the database
ERROR - 2019-07-01 17:41:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-01 17:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-01 17:43:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 17:43:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 17:43:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 17:43:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 17:43:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-01 17:43:51 --> 404 Page Not Found: admin/Penduduk/assets
