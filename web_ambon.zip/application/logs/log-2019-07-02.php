<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-02 04:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-02 04:25:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:25:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:25:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:25:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:34:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:34:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:34:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:34:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:34:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:34:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:35:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:35:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:35:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 04:35:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 05:46:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 05:51:33 --> Query error: Column 'tl_key' in where clause is ambiguous - Invalid query: SELECT *
FROM `kependudukan_vl`
JOIN `kependudukan_kl` ON `kependudukan_kl`.`id` = `kependudukan_vl`.`kl_id`
JOIN `kependudukan_tl` ON `kependudukan_tl`.`tl_id` = `kependudukan_vl`.`tl_id`
WHERE `kependudukan_tl`.`id_desa` = '1'
AND `tl_key` = 'pendidikan'
ERROR - 2019-07-02 06:08:51 --> Severity: Notice --> Undefined variable: tl_head_main D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 15
ERROR - 2019-07-02 06:08:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:08:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:08:52 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-02 06:10:15 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 43
ERROR - 2019-07-02 06:11:32 --> Severity: Notice --> Undefined variable: table D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 32
ERROR - 2019-07-02 06:11:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 15
ERROR - 2019-07-02 06:11:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:11:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:13:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:13:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:18:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:18:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:18:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:18:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:19:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:19:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Undefined variable: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Undefined variable: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Undefined variable: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Undefined variable: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Undefined variable: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:15 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-02 06:27:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:27:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:28:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:28:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:29:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:29:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:30:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:30:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:31:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:31:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:32:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:32:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:33:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:33:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:34:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:34:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:35:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:35:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:37:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:40:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:40:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:56:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 06:56:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:01:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:01:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:13:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:13:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:13:12 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-02 08:13:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:13:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-02 08:33:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:33:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:36:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:36:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:40:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:40:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:43:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:43:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:45:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:45:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:46:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:46:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:48:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:48:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:48:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:48:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:50:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:50:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:50:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 08:50:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 23:45:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'web_ambon' D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-02 23:45:36 --> Unable to connect to the database
ERROR - 2019-07-02 23:49:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 23:49:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 23:49:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 23:52:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-02 23:52:06 --> 404 Page Not Found: Assets/backend
