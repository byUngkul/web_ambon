<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-10 01:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-10 01:56:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-10 01:56:57 --> Unable to connect to the database
ERROR - 2019-07-10 01:58:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-10 01:58:13 --> Unable to connect to the database
ERROR - 2019-07-10 01:58:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-10 01:58:19 --> Unable to connect to the database
ERROR - 2019-07-10 01:58:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-10 01:58:25 --> Unable to connect to the database
ERROR - 2019-07-10 01:58:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-10 01:58:28 --> Unable to connect to the database
ERROR - 2019-07-10 01:58:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 01:58:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 01:58:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 01:58:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 01:59:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 01:59:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 01:59:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 01:59:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:00:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:00:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:00:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:00:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:00:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:00:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:01:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:01:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:01:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:01:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:01:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:05:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:05:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:05:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:05:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:05:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:05:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:06:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:06:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:06:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:06:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:07:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:07:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:07:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:08:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:09:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:09:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:10:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:10:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:10:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:10:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:11:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:11:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:11:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:11:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:12:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:12:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:12:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:12:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:13:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:15:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:15:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:15:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:15:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:18:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:19:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:20:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:22:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:24:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-10 02:24:40 --> 404 Page Not Found: Assets/backend
