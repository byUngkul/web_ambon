<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-14 04:45:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 04:45:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:01:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:03:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:03:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:04:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:04:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:04:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:04:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:05:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:05:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:05:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:06:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:06:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:06:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:06:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:07:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:07:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 05:20:09 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 30
ERROR - 2019-07-14 06:23:05 --> Query error: Unknown column 'tl_tl_key' in 'group statement' - Invalid query: SELECT `tl`.`tl_id`, `tl`.`tl_text`, `tl`.`tl_key`
FROM `kependudukan_vl` `vl`
JOIN `kependudukan_kl` `kl` ON `kl`.`id` = `vl`.`kl_id`
JOIN `kependudukan_tl` `tl` ON `tl`.`tl_id` = `vl`.`tl_id`
GROUP BY `tl_tl_key`
ORDER BY `vl`.`id` ASC
ERROR - 2019-07-14 08:13:04 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 35
ERROR - 2019-07-14 08:13:14 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 35
ERROR - 2019-07-14 08:14:26 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 42
ERROR - 2019-07-14 08:15:09 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 42
ERROR - 2019-07-14 08:27:15 --> Query error: Unknown column 'desa_id' in 'field list' - Invalid query: INSERT INTO `kependudukan_tl` (`desa_id`, `tl_key`, `tl_text`) VALUES ('1','umur','Rentan Usia'), ('2','umur','Rentan Usia'), ('3','umur','Rentan Usia'), ('4','umur','Rentan Usia'), ('5','umur','Rentan Usia'), ('6','umur','Rentan Usia'), ('7','umur','Rentan Usia'), ('8','umur','Rentan Usia'), ('9','umur','Rentan Usia'), ('10','umur','Rentan Usia'), ('11','umur','Rentan Usia'), ('12','umur','Rentan Usia'), ('13','umur','Rentan Usia'), ('14','umur','Rentan Usia'), ('15','umur','Rentan Usia')
ERROR - 2019-07-14 11:45:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 11:45:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 11:45:57 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 11:46:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:21:01 --> Severity: Notice --> Undefined variable: kat_d D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 31
ERROR - 2019-07-14 12:21:01 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-14 12:21:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php:31) D:\xampp\htdocs\web_ambon\system\core\Common.php 570
ERROR - 2019-07-14 12:21:36 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 26
ERROR - 2019-07-14 12:26:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:26:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:27:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:27:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:27:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:27:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:28:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:28:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 12:53:17 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 64
ERROR - 2019-07-14 12:59:03 --> Severity: Compile Error --> Cannot redeclare Penduduk_m::insert_kateg() D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 55
ERROR - 2019-07-14 14:14:15 --> Severity: Notice --> Undefined variable: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 69
ERROR - 2019-07-14 14:26:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:26:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:26:26 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 14:26:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:26:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:26:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:26:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:26:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:26:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:36:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:36:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:36:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:36:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:37:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:37:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:43:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:43:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:46:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:46:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:50:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:50:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:53:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:53:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:53:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:53:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:55:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:55:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 14:55:18 --> 404 Page Not Found: admin/Penduduk/detile15
ERROR - 2019-07-14 15:23:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:30:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:30:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:32:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:32:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:49:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:49:32 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 15:51:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:51:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 15:51:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-14 17:27:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:27:14 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 17:27:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:27:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:27:16 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 17:27:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:27:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:27:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:28:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:28:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:28:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:28:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:28:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:28:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:29:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-14 17:29:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:29:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:33:17 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 64
ERROR - 2019-07-14 17:33:18 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 65
ERROR - 2019-07-14 17:36:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\system\database\DB_query_builder.php 2013
ERROR - 2019-07-14 17:37:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:37:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:37:01 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 17:48:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:48:47 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 17:48:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:49:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:49:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:52:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:52:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:52:38 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 17:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:53:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:53:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:53:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 17:53:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:00:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-14 18:02:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:22 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-14 18:02:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:02:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:03:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:04:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:04:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:05:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:05:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:05:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:05:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:06:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:06:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:06:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:06:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:06:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:11:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:11:41 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 18:12:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:12:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:13:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:13:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:13:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:13:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:14:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:17:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:18:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:18:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:19:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:19:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:32:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:32:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:37:07 --> Severity: Notice --> Undefined index: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 194
ERROR - 2019-07-14 18:37:07 --> Severity: Notice --> Undefined index: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 194
ERROR - 2019-07-14 18:37:07 --> Severity: Notice --> Undefined index: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 194
ERROR - 2019-07-14 18:37:07 --> Severity: Notice --> Undefined index: key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 194
ERROR - 2019-07-14 18:37:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:37:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:37:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:37:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:37:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:37:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:38:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:38:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:39:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:39:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:39:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-14 18:40:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:40:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:42:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:42:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:44:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:44:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:44:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:44:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:44:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:44:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:44:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:51:48 --> Query error: Column 'tl_key' in group statement is ambiguous - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
GROUP BY `tl_key`
ERROR - 2019-07-14 18:53:07 --> Query error: Unknown column 'kl.kl.text' in 'field list' - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`tl_key`, `kl`.`kl`.`text`
FROM `kependudukan_tl` `tl`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
GROUP BY `tl_key`
ERROR - 2019-07-14 18:53:14 --> Query error: Column 'tl_key' in group statement is ambiguous - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`tl_key`, `kl`.`kl_text`
FROM `kependudukan_tl` `tl`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
GROUP BY `tl_key`
ERROR - 2019-07-14 18:54:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:54:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:57:59 --> Query error: Unknown column 'kl.tl_key' in 'field list' - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`tl_key`, `kl`.`kl_text`
FROM `kependudukan_tl` `tl`
GROUP BY `tl`.`tl_key`
ERROR - 2019-07-14 18:58:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 18:58:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:02:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:10:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:10:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:13:01 --> Severity: Notice --> Undefined variable: isisnya D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 62
ERROR - 2019-07-14 19:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 62
ERROR - 2019-07-14 19:13:01 --> Severity: Notice --> Undefined variable: isisnya D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 62
ERROR - 2019-07-14 19:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 62
ERROR - 2019-07-14 19:13:01 --> Severity: Notice --> Undefined variable: isisnya D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 62
ERROR - 2019-07-14 19:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 62
ERROR - 2019-07-14 19:13:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:13:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:13:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:13:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:16:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:16:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:18:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:18:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-14 19:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-14 19:46:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:46:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:32 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-14 19:48:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:39 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-14 19:48:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:48:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-14 19:51:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-14 20:01:41 --> 404 Page Not Found: 
ERROR - 2019-07-14 20:01:42 --> 404 Page Not Found: Kegiatan/assets
