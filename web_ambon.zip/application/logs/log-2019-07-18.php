<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-18 04:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-18 04:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 04:42:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 04:42:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 04:44:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 04:45:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 04:46:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 04:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 09:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:00:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:05:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:06:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:07:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:09:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:09:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:10:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:11:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-18 10:15:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:33:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:33:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:37:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:38:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:39:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:39:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:40:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:41:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:42:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:43:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:44:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:44:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:46:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:47:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:47:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:47:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:48:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:48:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:48:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:49:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:49:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:50:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:50:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:50:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:51:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:51:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:52:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:53:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 10:54:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:01:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:05:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:07:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:51:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:52:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:53:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:53:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 11:54:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 12:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-18 12:20:54 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2019-07-18 12:20:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-18 12:21:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 12:23:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 12:23:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 12:23:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:30:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:32:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:39:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:44:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:45:52 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\web_ambon\application\views\_blocks\organ.php 15
ERROR - 2019-07-18 13:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:50:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:56:33 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 13:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 13:59:45 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 13:59:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 14:02:32 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 14:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 14:03:11 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 14:03:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 14:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 14:03:53 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 14:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-07-18 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:14:48 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 14:29:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:29:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:29:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:29:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:29:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:29:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:29:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:29:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:33:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:33:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:33:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:33:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:33:56 --> Severity: Error --> Class 'CI_Model' not found D:\xampp\htdocs\web_ambon\application\controllers\admin\Organisasi.php 3
ERROR - 2019-07-18 14:34:22 --> Severity: Notice --> Undefined variable: desas D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\index.php 22
ERROR - 2019-07-18 14:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\index.php 22
ERROR - 2019-07-18 14:34:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:34:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:35:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:35:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:37:57 --> Severity: Notice --> Undefined variable: pegawai D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 2
ERROR - 2019-07-18 14:37:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 2
ERROR - 2019-07-18 14:37:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:37:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:38:14 --> Severity: Notice --> Undefined variable: pegawai D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 2
ERROR - 2019-07-18 14:38:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 2
ERROR - 2019-07-18 14:38:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:38:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:38:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:38:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:38:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:38:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:40:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:40:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:46:58 --> Severity: Parsing Error --> syntax error, unexpected '$', expecting variable (T_VARIABLE) D:\xampp\htdocs\web_ambon\application\models\Organisasi_m.php 5
ERROR - 2019-07-18 14:47:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:47:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:50:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:50:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:52:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:53:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:53:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:53:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:53:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:55:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:55:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:55:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:55:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:56:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 14:56:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 15:00:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 15:00:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 15:03:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 15:03:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 15:03:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 15:03:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 16:54:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 16:54:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:02:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\index.php 36
ERROR - 2019-07-18 17:02:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\index.php 36
ERROR - 2019-07-18 17:02:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\index.php 36
ERROR - 2019-07-18 17:02:00 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\index.php 36
ERROR - 2019-07-18 17:02:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:02:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:02:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:02:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:05:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:06:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:06:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:06:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:06:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:07:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:07:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:07:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:07:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:07:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:07:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:08:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:09:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:09:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:10:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:10:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:14:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:14:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:15:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:15:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:16:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:16:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:17:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:17:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:17:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:17:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:19:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:19:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:19:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:19:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:20:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:20:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:25:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:25:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Undefined variable: rom D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Undefined variable: rom D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Undefined variable: rom D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Undefined variable: rom D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Undefined variable: rom D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Undefined variable: rom D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 22
ERROR - 2019-07-18 17:26:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:26:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:28:31 --> Severity: Notice --> Undefined property: CI_Loader::$jabatan_m D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 32
ERROR - 2019-07-18 17:28:31 --> Severity: Error --> Call to a member function get_jabatan() on null D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 32
ERROR - 2019-07-18 17:28:56 --> Severity: Notice --> Undefined property: CI_Loader::$jabatan_m D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 32
ERROR - 2019-07-18 17:28:56 --> Severity: Error --> Call to a member function get_jabatan() on null D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 32
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Undefined property: mysqli::$id D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Undefined property: mysqli::$nama_jb D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Undefined property: mysqli_result::$id D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Undefined property: mysqli_result::$nama_jb D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:29:26 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 36
ERROR - 2019-07-18 17:31:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:31:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:32:57 --> Severity: Notice --> Undefined property: mysqli::$id D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:57 --> Severity: Notice --> Undefined property: mysqli::$nama_jb D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:57 --> Severity: Notice --> Undefined property: mysqli_result::$id D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:57 --> Severity: Notice --> Undefined property: mysqli_result::$nama_jb D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 50
ERROR - 2019-07-18 17:32:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:32:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:34:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:34:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:41:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:41:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:48:11 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) D:\xampp\htdocs\web_ambon\application\models\Organisasi_m.php 29
ERROR - 2019-07-18 17:48:34 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) D:\xampp\htdocs\web_ambon\application\models\Organisasi_m.php 29
ERROR - 2019-07-18 17:49:32 --> Severity: Notice --> Undefined index: id_1 D:\xampp\htdocs\web_ambon\application\models\Organisasi_m.php 23
ERROR - 2019-07-18 17:49:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:49:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:50:44 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 17:50:44 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 17:54:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:54:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:56:45 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 151
ERROR - 2019-07-18 17:56:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:56:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:59:30 --> Severity: Parsing Error --> syntax error, unexpected '>' D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 98
ERROR - 2019-07-18 17:59:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 17:59:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:00:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:00:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:24 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:25 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:02:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:43 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:02:44 --> Severity: Notice --> Undefined index: id_desa D:\xampp\htdocs\web_ambon\application\views\_admin\organisasi\modal_item.php 138
ERROR - 2019-07-18 18:04:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:04:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:06:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:06:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:11:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:11:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:11:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:11:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:12:04 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 18:12:04 --> 404 Page Not Found: Assets/images
ERROR - 2019-07-18 18:13:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:13:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:13:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:13:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:15:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:15:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:16:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:16:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:17:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:17:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:17:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:17:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:17:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:17:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:19:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:19:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:19:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:19:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:20:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-18 18:20:03 --> 404 Page Not Found: Assets/backend
