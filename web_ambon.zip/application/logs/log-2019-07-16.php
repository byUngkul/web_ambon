<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-16 02:40:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:40:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:41:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:42:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:48:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:52:41 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\modal_kateg.php 151
ERROR - 2019-07-16 02:52:45 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\modal_kateg.php 151
ERROR - 2019-07-16 02:53:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:53:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:58:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 02:59:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:00:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:03:35 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\modal_kateg.php 129
ERROR - 2019-07-16 03:03:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:12:41 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\add_titlekateg.php 2
ERROR - 2019-07-16 03:12:41 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\add_titlekateg.php 2
ERROR - 2019-07-16 03:12:41 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\add_titlekateg.php 2
ERROR - 2019-07-16 03:12:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:14:36 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\add_titlekateg.php 2
ERROR - 2019-07-16 03:14:36 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\add_titlekateg.php 2
ERROR - 2019-07-16 03:14:36 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\add_titlekateg.php 2
ERROR - 2019-07-16 03:14:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:15:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:19:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:21:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:28:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:32:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 86
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 95
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:32:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:32:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 86
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 95
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:32:35 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:32:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:34:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Undefined variable: jabatan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 14
ERROR - 2019-07-16 03:34:21 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 22
ERROR - 2019-07-16 03:35:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:35:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:35:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:35:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:38:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 03:38:27 --> Severity: Notice --> Undefined variable: kat_p D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 97
ERROR - 2019-07-16 03:38:27 --> Severity: Notice --> Undefined variable: kat_data D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 99
ERROR - 2019-07-16 03:44:18 --> Query error: Unknown column 'kl.tl_text' in 'where clause' - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`tl_key`, `kl`.`kl_text`
FROM `kependudukan_tl` `tl`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
WHERE `kl`.`tl_text` = 'Sekolah%20Dasar'
GROUP BY `kl`.`kl_text`
ORDER BY `kl`.`id` ASC
ERROR - 2019-07-16 04:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-16 04:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-16 04:53:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-16 04:53:54 --> Unable to connect to the database
ERROR - 2019-07-16 04:53:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-16 05:00:08 --> Query error: Unknown column 'kl.tl_text' in 'where clause' - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`tl_key`, `kl`.`kl_text`
FROM `kependudukan_tl` `tl`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
WHERE `kl`.`tl_text` = 'pendidikan'
GROUP BY `kl`.`kl_text`
ORDER BY `kl`.`id` ASC
ERROR - 2019-07-16 05:00:09 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-16 05:02:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:02:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:03:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:03:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:16:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:16:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:18:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:21:28 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 62
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:22:14 --> Severity: Notice --> Undefined index: tl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:15 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:15 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 99
ERROR - 2019-07-16 05:23:16 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 100
ERROR - 2019-07-16 05:24:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:24:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:26:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:26:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:26:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:26:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:43:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:43:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:43:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:45:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:45:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:45:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:45:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:45:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:46:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:46:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:47:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:47:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:47:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:48:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:48:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:48:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:49:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:49:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:49:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:50:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:50:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:50:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:52:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 05:52:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:02:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:03:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:04:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:08:09 --> Query error: Unknown column '15' in 'group statement' - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
GROUP BY 15
ERROR - 2019-07-16 06:08:09 --> Query error: Unknown column '15' in 'group statement' - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
GROUP BY 15
ERROR - 2019-07-16 06:09:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:09:43 --> Severity: Notice --> Undefined variable: kat_p D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 41
ERROR - 2019-07-16 06:09:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:09:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:29:24 --> Severity: Notice --> Undefined variable: kat_p D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 80
ERROR - 2019-07-16 06:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 80
ERROR - 2019-07-16 06:29:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:31:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:31:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:34:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:19 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:20 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:34:21 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:36:36 --> Query error: Unknown column 'pendidikan' in 'group statement' - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
GROUP BY `pendidikan`
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:28 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:29 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:38:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:38:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:16 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:17 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:39:18 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:42:49 --> Query error: Unknown column 'kl.id_desa' in 'where clause' - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `tl`.`tl_key`
ERROR - 2019-07-16 06:43:39 --> Query error: Unknown column 'kl.id_desa' in 'where clause' - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `tl`.`tl_key`
ERROR - 2019-07-16 06:45:07 --> Query error: Unknown column 'kl.id_desa' in 'where clause' - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `tl`.`tl_key`
ERROR - 2019-07-16 06:45:51 --> Query error: Unknown column 'kl.id_desa' in 'where clause' - Invalid query: SELECT *
FROM `kependudukan_tl` `tl`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `tl`.`tl_key`
ERROR - 2019-07-16 06:49:14 --> Severity: Parsing Error --> syntax error, unexpected 'menu' (T_STRING) D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 34
ERROR - 2019-07-16 06:49:46 --> Query error: Not unique table/alias: 'kl' - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`tl_key`, `kl`.`kl_text`, `tl`.`id_desa`, `kl`.`id_desa`
FROM `kependudukan_tl` `tl`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
WHERE `kl`.`kl_text` IS NULL
AND `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `kl`.`kl_text`
ORDER BY `kl`.`id` ASC
ERROR - 2019-07-16 06:50:31 --> Query error: Not unique table/alias: 'kl' - Invalid query: SELECT `tl`.`tl_key`, `tl`.`tl_text`, `kl`.`tl_key`, `kl`.`kl_text`, `tl`.`id_desa`, `kl`.`id_desa`
FROM `kependudukan_tl` `tl`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
JOIN `kependudukan_kl` `kl` ON `kl`.`tl_key` = `tl`.`tl_key`
WHERE `kl`.`kl_text` IS NULL
AND `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `kl`.`kl_text`
ORDER BY `kl`.`id` ASC
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:52:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:04 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:05 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:06 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:07 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:08 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:09 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:10 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:11 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:12 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:13 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:15 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\xampp\htdocs\web_ambon\system\core\Log.php 231
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:35 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:36 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:38 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:39 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:40 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:41 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:42 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:43 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:44 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:45 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:46 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:47 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:48 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:49 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:50 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:51 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:52 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:53 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:54 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:55 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:56 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:57 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:58 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:53:59 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:00 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:01 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 06:54:03 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\xampp\htdocs\web_ambon\system\core\Log.php 231
ERROR - 2019-07-16 06:55:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:55:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:56:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 06:56:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:41:28 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 116
ERROR - 2019-07-16 07:42:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:42:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:42:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:42:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:43:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:43:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:44:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:44:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:44:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 07:44:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:04:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:04:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:21:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:21:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:21:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:21:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:32:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:32:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:32:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:32:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:33:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:33:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:33:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:33:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:34:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:34:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:36:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 09:36:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 10:22:12 --> Query error: Unknown column 'id' in 'field list' - Invalid query: SELECT `id`
FROM `desa`
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:22:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:23:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:26:54 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 10:27:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:27:10 --> Severity: Notice --> Undefined variable: s D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 92
ERROR - 2019-07-16 10:45:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 10:45:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 10:45:31 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 98
ERROR - 2019-07-16 10:45:31 --> Severity: Notice --> Undefined variable: dat D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 99
ERROR - 2019-07-16 10:45:31 --> Severity: Notice --> Undefined variable: dat D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 100
ERROR - 2019-07-16 10:45:31 --> Query error: Column 'kl_text' cannot be null - Invalid query: INSERT INTO `kependudukan_kl` (`id_desa`, `kl_text`, `tl_key`) VALUES (0, NULL, '')
ERROR - 2019-07-16 10:51:53 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting variable (T_VARIABLE) or '$' D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 100
ERROR - 2019-07-16 10:52:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 10:52:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 10:52:23 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 98
ERROR - 2019-07-16 10:52:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`web_ambon`.`kependudukan_kl`, CONSTRAINT `kependudukan_kl_desa_id` FOREIGN KEY (`id_desa`) REFERENCES `desa` (`desa_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `kependudukan_kl` (`id_desa`, `kl_text`, `tl_key`) VALUES (0, 'Tidak Sekolah', 'pendidikan')
ERROR - 2019-07-16 11:11:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:11:32 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-16 11:12:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:12:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:12:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:12:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:12:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:12:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:13:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:13:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:14:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:15:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:15:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:15:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:15:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:15:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:15:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:16:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:16:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:17:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:17:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:23 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:25 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:26 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:27 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 103
ERROR - 2019-07-16 11:17:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:17:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:18:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:18:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:20:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:20:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:28:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:28:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:57:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 11:57:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 12:00:48 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 120
ERROR - 2019-07-16 12:01:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 12:01:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-16 14:01:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:01:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:01:42 --> 404 Page Not Found: admin/Penduduk/assets
ERROR - 2019-07-16 14:02:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:02:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:02:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:07:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:08:01 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 113
ERROR - 2019-07-16 14:08:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 106
ERROR - 2019-07-16 14:08:01 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2019-07-16 14:08:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 108
ERROR - 2019-07-16 14:08:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`web_ambon`.`kependudukan_kl`, CONSTRAINT `kependudukan_kl_desa_id` FOREIGN KEY (`id_desa`) REFERENCES `desa` (`desa_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `kependudukan_kl` (`id_desa`, `kl_text`, `tl_key`) VALUES (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan'), (NULL,'Tidak Sekola','pendidikan')
ERROR - 2019-07-16 14:08:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\web_ambon\system\core\Exceptions.php:271) D:\xampp\htdocs\web_ambon\system\core\Common.php 570
ERROR - 2019-07-16 14:09:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:09:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:09:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:09:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:10:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:10:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:11:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:11:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:11:42 --> 404 Page Not Found: admin/Penduduk/edit_j_kateg
ERROR - 2019-07-16 14:11:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:13:37 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:13:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:14:02 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:14:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:14:14 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:14:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:14:48 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:14:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:15:29 --> Severity: Notice --> Undefined index: tl_key D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:15:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:16:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:16:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:17:51 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:17:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:17:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:17:52 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:18:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:18:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:18:24 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:18:33 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:18:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:18:34 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 13
ERROR - 2019-07-16 14:18:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:28:22 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 20
ERROR - 2019-07-16 14:28:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:28:22 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 20
ERROR - 2019-07-16 14:28:47 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 20
ERROR - 2019-07-16 14:28:48 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 20
ERROR - 2019-07-16 14:29:15 --> Severity: Notice --> Undefined variable: kl D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 20
ERROR - 2019-07-16 14:29:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:29:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:29:16 --> Severity: Notice --> Undefined variable: kl D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 20
ERROR - 2019-07-16 14:29:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:29:21 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\edit_jkateg.php 20
ERROR - 2019-07-16 14:34:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:36:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:55:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:55:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:55:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 14:56:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:00:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:00:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:00:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:02:33 --> Severity: Notice --> Undefined variable: kl_id D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 125
ERROR - 2019-07-16 15:07:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:07:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:07:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:12:15 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::udapte_batch() D:\xampp\htdocs\web_ambon\application\models\Penduduk_m.php 128
ERROR - 2019-07-16 15:14:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:14:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:14:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:15:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:15:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:15:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:16:02 --> Severity: Notice --> Undefined index: desa_id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 130
ERROR - 2019-07-16 15:16:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:17:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:17:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:17:30 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 130
ERROR - 2019-07-16 15:17:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:17:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:17:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:17:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:18:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:18:49 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-16 15:18:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:19:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:19:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:19:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:24:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:28:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:19 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:28:48 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:48 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:48 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:28:49 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:49 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:49 --> Severity: Notice --> Undefined variable: val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:28:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:29:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:29:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:29:24 --> Severity: Notice --> Undefined index: kl_text D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 101
ERROR - 2019-07-16 15:29:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:29:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:30:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:31:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:31:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:32:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:33:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:43:37 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 104
ERROR - 2019-07-16 15:43:48 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 104
ERROR - 2019-07-16 15:45:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:59:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 15:59:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:01:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:01:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:03:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:03:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:04:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:05:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:05:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:06:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:06:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:07:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:07:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:11:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:11:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:11:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:15:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:15:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:31:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-16 16:31:22 --> 404 Page Not Found: Assets/backend
