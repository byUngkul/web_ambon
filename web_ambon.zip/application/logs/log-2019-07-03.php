<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-03 00:15:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:15:39 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-03 00:21:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:21:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:21:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:21:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:21:48 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-03 00:22:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:22:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:33:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:33:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:31 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 29
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 36
ERROR - 2019-07-03 00:33:32 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 37
ERROR - 2019-07-03 00:33:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:33:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:35:55 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:35:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_laki D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:58 --> Severity: Notice --> Undefined property: stdClass::$jumlah_perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\desa\index.php 27
ERROR - 2019-07-03 00:35:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:35:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:36:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:36:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:37:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:37:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:37:37 --> 404 Page Not Found: admin/Desa/assets
ERROR - 2019-07-03 00:38:21 --> 404 Page Not Found: 
ERROR - 2019-07-03 00:38:22 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-03 00:38:22 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-03 00:43:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:43:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:43:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:43:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:47:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:47:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:50:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:50:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:51:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:51:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:52:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:52:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:52:02 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-03 00:54:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:54:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:54:19 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-03 00:54:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:54:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:54:48 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-03 00:55:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:55:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 00:55:05 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-03 02:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-03 02:53:25 --> 404 Page Not Found: Kelurahan-karang%20-panjang/home
ERROR - 2019-07-03 03:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-03 03:45:55 --> Severity: Notice --> Undefined property: stdClass::$telp D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:45:55 --> Severity: Notice --> Undefined property: stdClass::$telp2 D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:45:55 --> Severity: Notice --> Undefined property: stdClass::$alamat_kantor D:\xampp\htdocs\web_ambon\application\views\v_home.php 291
ERROR - 2019-07-03 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$name D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-03 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$telp D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$telp2 D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$alamat_kantor D:\xampp\htdocs\web_ambon\application\views\v_home.php 291
ERROR - 2019-07-03 03:47:51 --> Severity: Notice --> Undefined property: stdClass::$telp D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:47:51 --> Severity: Notice --> Undefined property: stdClass::$telp2 D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:47:51 --> Severity: Notice --> Undefined property: stdClass::$alamat_kantor D:\xampp\htdocs\web_ambon\application\views\v_home.php 291
ERROR - 2019-07-03 03:48:11 --> Severity: Notice --> Undefined property: stdClass::$telp D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:48:11 --> Severity: Notice --> Undefined property: stdClass::$telp2 D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:48:11 --> Severity: Notice --> Undefined property: stdClass::$alamat_kantor D:\xampp\htdocs\web_ambon\application\views\v_home.php 291
ERROR - 2019-07-03 03:48:50 --> Severity: Notice --> Undefined property: stdClass::$telp D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:48:50 --> Severity: Notice --> Undefined property: stdClass::$telp2 D:\xampp\htdocs\web_ambon\application\views\v_home.php 267
ERROR - 2019-07-03 03:48:50 --> Severity: Notice --> Undefined property: stdClass::$alamat_kantor D:\xampp\htdocs\web_ambon\application\views\v_home.php 291
ERROR - 2019-07-03 04:50:47 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` = 'judul-kedua'
ERROR - 2019-07-03 04:50:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-03 04:53:40 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` = 'judul-kedua'
ERROR - 2019-07-03 04:54:40 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` = 'judul-kedua'
ERROR - 2019-07-03 04:56:58 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` = 'judul-kedua'
ERROR - 2019-07-03 04:57:02 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` IS NULL
ERROR - 2019-07-03 04:57:06 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-03 04:57:06 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-03 04:57:31 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-03 04:57:31 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-03 05:00:46 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-03 05:00:46 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-03 05:00:46 --> Severity: Notice --> Undefined variable: kecamtan D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-03 05:00:46 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-03 05:01:23 --> Severity: Notice --> Undefined variable: kecamtan D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-03 05:01:23 --> Severity: Notice --> Trying to get property 'nama' of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-03 06:26:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:26:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:26:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:26:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:26:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:26:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:26:30 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-03 06:33:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:33:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:33:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:33:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:33:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:33:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:33:18 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 06:34:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:34:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:48:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:48:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:48:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:48:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:48:40 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 29
ERROR - 2019-07-03 06:50:53 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 29
ERROR - 2019-07-03 06:52:14 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:52:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:52:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:52:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:55:16 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:55:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:55:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:55:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:55:50 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:55:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:55:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:57:18 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 06:57:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 06:57:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:00:33 --> Severity: Notice --> Undefined variable: post_image D:\xampp\htdocs\web_ambon\application\models\Pegawai_m.php 57
ERROR - 2019-07-03 07:00:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:00:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:00:37 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 07:00:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 07:00:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:00:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:00:46 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 07:00:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\edit.php 27
ERROR - 2019-07-03 07:00:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:00:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:01:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:01:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:01:37 --> Severity: Notice --> Undefined variable: post_image D:\xampp\htdocs\web_ambon\application\models\Pegawai_m.php 57
ERROR - 2019-07-03 07:01:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:01:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:04:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:04:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:05:13 --> Severity: Notice --> Undefined variable: post_image D:\xampp\htdocs\web_ambon\application\models\Pegawai_m.php 57
ERROR - 2019-07-03 07:05:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:05:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:07:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:07:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:07:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:07:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:07:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:07:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:08:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:08:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:10:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:10:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:09 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 07:15:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:15:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:16:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:16:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:16:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:16:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:16:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:16:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:27:27 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 12
ERROR - 2019-07-03 07:27:27 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 12
ERROR - 2019-07-03 07:27:27 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 12
ERROR - 2019-07-03 07:27:27 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 12
ERROR - 2019-07-03 07:27:27 --> Severity: Notice --> Undefined property: stdClass::$title D:\xampp\htdocs\web_ambon\application\views\_admin\pegawai\delete.php 12
ERROR - 2019-07-03 07:27:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:27:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:27:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:27:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:34:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:34:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:38:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:38:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:38:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:38:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:39:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:39:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:40:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:40:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:40:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:40:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:41:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 07:41:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 08:08:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 08:08:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 08:09:00 --> Severity: error --> Exception: syntax error, unexpected 'funcion' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\web_ambon\application\models\Jabatan_m.php 5
ERROR - 2019-07-03 08:09:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 08:09:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 09:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-03 09:27:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 09:27:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 09:29:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 09:29:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:03:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:03:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:03:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:03:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:03:32 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:06:33 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\add.php 25
ERROR - 2019-07-03 10:06:45 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\add.php 20
ERROR - 2019-07-03 10:06:45 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\add.php 20
ERROR - 2019-07-03 10:06:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:06:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:06:49 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\add.php 20
ERROR - 2019-07-03 10:06:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\add.php 20
ERROR - 2019-07-03 10:06:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:06:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:06:50 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:07:22 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\add.php 20
ERROR - 2019-07-03 10:07:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\add.php 20
ERROR - 2019-07-03 10:07:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:07:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:09:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:09:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:09:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:09:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:09:24 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:09:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:09:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:10:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:10:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:10:05 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:11:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:11:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:11:02 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:11:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:11:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:11:41 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:12:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:12:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:12:01 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:13:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:13:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:13:33 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:13:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:13:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:13:52 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:14:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:14:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:14:07 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:14:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:14:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:14:28 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:19:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:19:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:19:00 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:31:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:31:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:31:09 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-03 10:31:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 10:31:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-03 13:41:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:41:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:41:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:41:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:41:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:49:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:49:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:49:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:49:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:49:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:49:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:51:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:51:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:52:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:52:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:52:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:52:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:52:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:53:17 --> Severity: Notice --> Undefined property: Jabatan::$jabatan D:\xampp\htdocs\web_ambon\application\controllers\admin\Jabatan.php 61
ERROR - 2019-07-03 13:53:17 --> Severity: error --> Exception: Call to a member function insert() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Jabatan.php 61
ERROR - 2019-07-03 13:53:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:53:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:53:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:53:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:54:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 13:54:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:26:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:26:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:28:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:28:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:28:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:28:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:28:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:28:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-03 14:28:40 --> 404 Page Not Found: admin/Jabatan/assets
