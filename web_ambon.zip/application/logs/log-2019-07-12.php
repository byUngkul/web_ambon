<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-12 05:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-12 05:37:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 05:37:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 05:37:57 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-12 05:37:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 06:51:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 06:51:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 06:56:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 06:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 06:56:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:32:40 --> Severity: Notice --> Undefined property: Infrastruktur::$bs D:\xampp\htdocs\web_ambon\system\core\Model.php 73
ERROR - 2019-07-12 08:32:40 --> Severity: Error --> Call to a member function insert() on null D:\xampp\htdocs\web_ambon\application\models\Infrastruktur_m.php 42
ERROR - 2019-07-12 08:33:23 --> Query error: Unknown column 'desa_id' in 'field list' - Invalid query: INSERT INTO `infrastruktur_v` (`nama_infra`, `value`, `desa_id`, `id_jenis_infra`) VALUES ('Sekolah Dasar', '2', '1', '1')
ERROR - 2019-07-12 08:33:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:33:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:33:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:33:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:34:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:34:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:34:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:35:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:35:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:35:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:35:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:35:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:35:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:36:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:52:17 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:52:17 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:52:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:52:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:54:10 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:10 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:54:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 37
ERROR - 2019-07-12 08:54:25 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\detile.php 38
ERROR - 2019-07-12 08:54:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:54:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:54:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:54:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 08:55:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:01:21 --> Severity: Warning --> Missing argument 1 for Infrastruktur::edit_infra() D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 91
ERROR - 2019-07-12 09:02:04 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::result_row() D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 94
ERROR - 2019-07-12 09:02:28 --> 404 Page Not Found: User_guide/index
ERROR - 2019-07-12 09:17:52 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 5
ERROR - 2019-07-12 09:17:52 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 11
ERROR - 2019-07-12 09:17:52 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 12
ERROR - 2019-07-12 09:17:55 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 5
ERROR - 2019-07-12 09:17:55 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 11
ERROR - 2019-07-12 09:17:55 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 12
ERROR - 2019-07-12 09:17:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:17:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:17:56 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-12 09:18:18 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 5
ERROR - 2019-07-12 09:18:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:19 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 5
ERROR - 2019-07-12 09:18:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:26 --> 404 Page Not Found: admin/Infrastruktur/4
ERROR - 2019-07-12 09:18:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:42 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 5
ERROR - 2019-07-12 09:18:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:18:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:26:56 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 94
ERROR - 2019-07-12 09:26:56 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 5
ERROR - 2019-07-12 09:26:56 --> Severity: Notice --> Undefined variable: desa_id D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 11
ERROR - 2019-07-12 09:26:56 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 12
ERROR - 2019-07-12 09:26:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:27:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:27:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:29:37 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 12
ERROR - 2019-07-12 09:29:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:29:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:29:38 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 12
ERROR - 2019-07-12 09:35:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:36:46 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\edit_infra.php 15
ERROR - 2019-07-12 09:37:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:37:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:37:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 09:37:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:03:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:03:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-12 10:07:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\web_ambon\application\models\Infrastruktur_m.php 62
ERROR - 2019-07-12 10:07:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:07:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:07:57 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-12 10:08:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:08:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:09:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:09:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:11:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:11:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:12:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:12:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:14:39 --> 404 Page Not Found: admin/Infrastruktur/delete_infra
ERROR - 2019-07-12 10:21:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:23:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:23:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:23:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:23:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:24:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:24:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:24:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:24:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:39:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:39:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:39:31 --> 404 Page Not Found: admin/Infrastruktur/assets
ERROR - 2019-07-12 10:39:51 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\delete_infra.php 23
ERROR - 2019-07-12 10:40:06 --> Severity: Notice --> Undefined variable: jenis_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\delete_infra.php 3
ERROR - 2019-07-12 10:40:06 --> Severity: Notice --> Undefined variable: jenis_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\delete_infra.php 3
ERROR - 2019-07-12 10:40:06 --> Severity: Notice --> Undefined variable: jenis_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\delete_infra.php 3
ERROR - 2019-07-12 10:40:06 --> Severity: Notice --> Undefined variable: jenis_infra D:\xampp\htdocs\web_ambon\application\views\_admin\infrastruktur\delete_infra.php 3
ERROR - 2019-07-12 10:43:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:43:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:45:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:45:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:45:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:45:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:46:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:46:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:46:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:46:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:46:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:46:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:47:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 10:47:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:02:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:02:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:05:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:05:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:05:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:59:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:59:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 11:59:40 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-12 11:59:46 --> Severity: Notice --> Undefined property: Potensi::$infrastruktur_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 33
ERROR - 2019-07-12 11:59:46 --> Severity: Error --> Call to a member function get_j_infra() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 33
ERROR - 2019-07-12 12:32:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:32:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:33:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:34:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:34:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:34:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:34:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:39:31 --> Severity: Notice --> Undefined property: Potensi::$potensi_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 33
ERROR - 2019-07-12 12:39:31 --> Severity: Error --> Call to a member function get_j_potensi() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 33
ERROR - 2019-07-12 12:39:59 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 45
ERROR - 2019-07-12 12:41:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:41:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:41:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:41:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:48:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:48:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:48:03 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\detile.php 10
ERROR - 2019-07-12 12:48:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\detile.php 10
ERROR - 2019-07-12 12:48:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:48:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:48:03 --> 404 Page Not Found: admin/Potensi/assets
ERROR - 2019-07-12 12:48:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:48:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:50:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:50:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:51:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:51:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:52:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:52:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:52:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:52:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:52:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:53:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:53:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:54:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:57:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:57:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:57:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:57:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:58:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:58:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:58:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:58:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:59:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 12:59:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:00:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:00:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:01:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:01:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:01:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:01:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:01:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:01:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:02:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:02:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:02:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:03:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:03:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:03:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:03:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:03:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:06:02 --> Query error: Unknown column 'p,id_jp' in 'on clause' - Invalid query: SELECT `p`.*, `j`.`nama`, `d`.`desa_id`, `d`.`nama`, `d`.`slug`
FROM `potensi_v` `p`
JOIN `jenis_potensi` `j` ON `j`.`id_jp` = `p,id_jp`
JOIN `desa` `d` ON `d`.`desa_id` = `p`.`id_desa`
ERROR - 2019-07-12 13:08:18 --> Query error: Unknown column 'p,id_jp' in 'on clause' - Invalid query: SELECT `p`.`id`, `p`.`id_jp`, `p`.`id_desa`, `p`.`nama_p`, `j`.`nama`, `d`.`desa_id`, `d`.`nama`, `d`.`slug`
FROM `potensi_v` `p`
JOIN `jenis_potensi` `j` ON `j`.`id_jp` = `p,id_jp`
JOIN `desa` `d` ON `d`.`desa_id` = `p`.`id_desa`
ERROR - 2019-07-12 13:08:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:08:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:10:30 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\detile.php 49
ERROR - 2019-07-12 13:10:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:10:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:11:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:11:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:12:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:12:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:12:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 13:12:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-12 18:14:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-12 18:14:03 --> Unable to connect to the database
ERROR - 2019-07-12 18:14:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-12 18:14:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:14:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:14:57 --> Severity: Notice --> Undefined variable: Value D:\xampp\htdocs\web_ambon\application\models\Potensi_m.php 10
ERROR - 2019-07-12 18:14:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 5 - Invalid query: SELECT `p`.*, `j`.`nama` as `nama_jp`, `d`.`desa_id`, `d`.`nama`, `d`.`slug`
FROM `potensi_v` `p`
JOIN `jenis_potensi` `j` ON `j`.`id_jp` = `p`.`id_jp`
JOIN `desa` `d` ON `d`.`desa_id` = `p`.`id_desa`
WHERE  IS NULL
ERROR - 2019-07-12 18:14:57 --> 404 Page Not Found: admin/Potensi/assets
ERROR - 2019-07-12 18:18:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:18:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:20:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:21:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:21:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:28:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:28:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:33:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:33:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:33:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:33:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:35:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:35:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:36:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:36:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:36:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:36:48 --> 404 Page Not Found: admin/Potensi/add_infra
ERROR - 2019-07-12 18:38:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:38:13 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\add_potensi.php 12
ERROR - 2019-07-12 18:38:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:38:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:38:14 --> Severity: Notice --> Undefined variable: j_infra D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\add_potensi.php 12
ERROR - 2019-07-12 18:38:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:38:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:40:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:43:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:43:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:45:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:45:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:45:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:45:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:45:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:45:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:45:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:23 --> 404 Page Not Found: admin/Potensi/1
ERROR - 2019-07-12 18:46:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:46:47 --> Severity: Notice --> Undefined property: Potensi::$potensi D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 83
ERROR - 2019-07-12 18:46:47 --> Severity: Error --> Call to a member function add_potensi() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 83
ERROR - 2019-07-12 18:47:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:47:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:47:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:47:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:50:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:50:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:50:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:50:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:51:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:51:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:52:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:52:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:52:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 18:52:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:00:02 --> Severity: Notice --> Undefined variable: j_potensi D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\edit_potensi.php 12
ERROR - 2019-07-12 19:00:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:00:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:00:02 --> Severity: Notice --> Undefined variable: j_potensi D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\edit_potensi.php 12
ERROR - 2019-07-12 19:02:47 --> Severity: Notice --> Undefined variable: j_potensi D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\edit_potensi.php 12
ERROR - 2019-07-12 19:02:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:02:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:03:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:03:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:04:05 --> Severity: Notice --> Undefined property: Potensi::$infrastruktur_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 112
ERROR - 2019-07-12 19:04:05 --> Severity: Error --> Call to a member function update_infra() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 112
ERROR - 2019-07-12 19:04:18 --> Severity: Error --> Call to undefined method Potensi_m::update_infra() D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 112
ERROR - 2019-07-12 19:07:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:07:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:08:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:08:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:09:45 --> Query error: Duplicate entry '5' for key 'PRIMARY' - Invalid query: INSERT INTO `potensi_v` (`id`, `nama_p`) VALUES ('5', 'Budi daya ikan Mujahir')
ERROR - 2019-07-12 19:10:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:10:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:10:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:10:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:10:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:10:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:10:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:10:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:11:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:11:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:17:28 --> Severity: Notice --> Undefined index: id_jp D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\delete_potensi.php 3
ERROR - 2019-07-12 19:17:28 --> Severity: Notice --> Undefined index: id_jp D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\delete_potensi.php 3
ERROR - 2019-07-12 19:17:28 --> Severity: Notice --> Undefined index: id_jp D:\xampp\htdocs\web_ambon\application\views\_admin\potensi\delete_potensi.php 3
ERROR - 2019-07-12 19:17:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:17:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:20:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:20:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:22:48 --> Severity: Error --> Call to undefined method Potensi_m::delete_potensi() D:\xampp\htdocs\web_ambon\application\controllers\admin\Potensi.php 121
ERROR - 2019-07-12 19:23:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:23:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:24:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:24:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:24:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:24:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:24:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:25:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:25:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:27:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:28:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:28:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:29:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:29:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:29:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:29:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:30:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:30:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:30:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:31:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:32:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:33:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:33:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:33:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-12 19:33:15 --> 404 Page Not Found: Assets/backend
