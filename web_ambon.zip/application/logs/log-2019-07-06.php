<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-06 04:29:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-06 04:29:52 --> Unable to connect to the database
ERROR - 2019-07-06 04:29:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 04:30:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-06 04:30:05 --> Unable to connect to the database
ERROR - 2019-07-06 04:30:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 04:30:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 04:31:08 --> 404 Page Not Found: admin/Potensi/index
ERROR - 2019-07-06 04:32:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 04:32:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 04:34:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 04:34:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 04:54:22 --> Severity: Notice --> Undefined property: Infrastruktur::$infrastruktur_m D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 26
ERROR - 2019-07-06 04:54:22 --> Severity: Error --> Call to a member function get_infra() on null D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 26
ERROR - 2019-07-06 05:04:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-06 05:04:28 --> Unable to connect to the database
ERROR - 2019-07-06 05:04:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 05:21:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 05:21:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 05:21:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 05:21:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 05:21:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 05:21:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 05:21:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-06 05:27:07 --> Severity: Notice --> Undefined index: jenis_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 34
ERROR - 2019-07-06 05:27:16 --> Severity: Notice --> Undefined index: jenis_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 34
ERROR - 2019-07-06 05:27:47 --> Severity: Notice --> Undefined index: jenis_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 34
ERROR - 2019-07-06 05:27:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-06 05:31:29 --> Severity: Notice --> Undefined index: jenis_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 34
ERROR - 2019-07-06 05:32:06 --> Severity: Notice --> Undefined index: jenis_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 34
ERROR - 2019-07-06 05:32:21 --> Severity: Notice --> Undefined index: jenis_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 34
ERROR - 2019-07-06 05:33:08 --> Severity: Notice --> Undefined index: nama_infra D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 34
ERROR - 2019-07-06 05:37:12 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 37
ERROR - 2019-07-06 05:37:31 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 37
ERROR - 2019-07-06 05:37:38 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 37
ERROR - 2019-07-06 05:37:57 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 37
ERROR - 2019-07-06 05:38:55 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\web_ambon\application\controllers\admin\Infrastruktur.php 39
