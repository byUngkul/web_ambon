<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-13 11:52:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 11:54:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 11:54:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 11:54:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 12:51:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 12:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-13 13:06:13 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 31
ERROR - 2019-07-13 13:06:24 --> Severity: Notice --> Undefined variable: tl_head_main D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 39
ERROR - 2019-07-13 13:06:24 --> Severity: Notice --> Undefined variable: tl_head_top D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 40
ERROR - 2019-07-13 13:06:24 --> Severity: Notice --> Undefined variable: tb_val D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 41
ERROR - 2019-07-13 13:06:24 --> Severity: Notice --> Undefined variable: tb_val2 D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 43
ERROR - 2019-07-13 13:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-07-13 13:46:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 13:50:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:00:54 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\web_ambon\application\controllers\admin\Penduduk.php 28
ERROR - 2019-07-13 14:46:13 --> Severity: Notice --> Undefined variable: tl_head_main D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 15
ERROR - 2019-07-13 14:46:13 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 15
ERROR - 2019-07-13 14:46:13 --> Severity: Notice --> Undefined variable: tl_head_top D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 14:46:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 14:46:13 --> Severity: Notice --> Undefined variable: tb_val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 22
ERROR - 2019-07-13 14:46:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 22
ERROR - 2019-07-13 14:46:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:46:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:47:43 --> Severity: Notice --> Undefined variable: tl_head_main D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 15
ERROR - 2019-07-13 14:47:43 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 15
ERROR - 2019-07-13 14:47:43 --> Severity: Notice --> Undefined variable: tl_head_top D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 14:47:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 14:47:43 --> Severity: Notice --> Undefined variable: tb_val D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 22
ERROR - 2019-07-13 14:47:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 22
ERROR - 2019-07-13 14:47:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:47:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:52:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:52:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:52:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:52:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:52:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:55:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:55:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:35 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:56:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:57:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:57:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:57:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 14:57:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:02:44 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 12
ERROR - 2019-07-13 15:03:32 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 12
ERROR - 2019-07-13 15:04:33 --> Severity: Notice --> Undefined variable: desa D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 12
ERROR - 2019-07-13 15:04:33 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 12
ERROR - 2019-07-13 15:04:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:04:33 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:04:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:05:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:05:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:05:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:05:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:05:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:05:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 15:07:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:29 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 15:07:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:30 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:37 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 15:07:50 --> Severity: Notice --> Undefined index: nama D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 15:07:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:07:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:08:20 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 15:08:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:08:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:08:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:08:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:13:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:13:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:17:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:17:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:24:10 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 15:25:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 15:25:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:54:54 --> Severity: Notice --> Undefined variable: j_potensi D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 18
ERROR - 2019-07-13 16:54:54 --> Severity: Notice --> Undefined variable: j_potensi D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 18
ERROR - 2019-07-13 16:54:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:54:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:55:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:55:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:57:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:57:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:57:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:57:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:57:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:57:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:59:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:59:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:59:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 16:59:44 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:00:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:00:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:01:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:01:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:01:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:01:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:02:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:02:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:02:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:02:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:06:16 --> Query error: Unknown column 'Pendidikan' in 'group statement' - Invalid query: SELECT *
FROM `kependudukan_vl` `vl`
JOIN `kependudukan_kl` `kl` ON `kl`.`id` = `vl`.`kl_id`
JOIN `kependudukan_tl` `tl` ON `tl`.`tl_id` = `vl`.`tl_id`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `Pendidikan`
ORDER BY `vl`.`id` ASC
ERROR - 2019-07-13 17:07:17 --> Query error: Unknown column 'Pendidikan' in 'group statement' - Invalid query: SELECT *
FROM `kependudukan_vl` `vl`
JOIN `kependudukan_kl` `kl` ON `kl`.`id` = `vl`.`kl_id`
JOIN `kependudukan_tl` `tl` ON `tl`.`tl_id` = `vl`.`tl_id`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `Pendidikan`
ORDER BY `vl`.`id` ASC
ERROR - 2019-07-13 17:07:49 --> Query error: Column 'tl_key' in group statement is ambiguous - Invalid query: SELECT *
FROM `kependudukan_vl` `vl`
JOIN `kependudukan_kl` `kl` ON `kl`.`id` = `vl`.`kl_id`
JOIN `kependudukan_tl` `tl` ON `tl`.`tl_id` = `vl`.`tl_id`
WHERE `tl`.`id_desa` = '1'
AND `kl`.`id_desa` = '1'
GROUP BY `tl_key`
ORDER BY `vl`.`id` ASC
ERROR - 2019-07-13 17:14:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:14:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:17:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:21:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:22:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:22:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:23:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:23:51 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:24:15 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:24:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:48:40 --> Severity: Notice --> Undefined variable: pendidikan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 17:48:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 16
ERROR - 2019-07-13 17:48:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:48:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:49:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:49:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:49:53 --> Severity: Notice --> Undefined property: stdClass::$name D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 4
ERROR - 2019-07-13 17:49:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:49:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:50:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:50:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:52:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:52:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:52:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:52:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:52:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:53:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:53:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:53:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:53:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:53:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:53:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:59:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 17:59:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:00:52 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:02:45 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 39
ERROR - 2019-07-13 18:02:45 --> Severity: Notice --> Undefined index:  D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 39
ERROR - 2019-07-13 18:02:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:02:46 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:04:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:04:38 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:04:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:05:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:07:11 --> Severity: Notice --> Undefined index: perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 41
ERROR - 2019-07-13 18:07:11 --> Severity: Notice --> Undefined index: perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 41
ERROR - 2019-07-13 18:07:11 --> Severity: Notice --> Undefined index: perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 41
ERROR - 2019-07-13 18:07:11 --> Severity: Notice --> Undefined index: perempuan D:\xampp\htdocs\web_ambon\application\views\_admin\penduduk\detile.php 41
ERROR - 2019-07-13 18:07:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:07:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:08:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:08:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:08:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:08:37 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:12:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:12:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-13 18:12:22 --> 404 Page Not Found: Assets/backend
