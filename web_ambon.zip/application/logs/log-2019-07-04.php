<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-04 00:09:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-04 00:09:05 --> Unable to connect to the database
ERROR - 2019-07-04 00:09:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-04 00:09:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\web_ambon\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-07-04 00:09:24 --> Unable to connect to the database
ERROR - 2019-07-04 00:09:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:09:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:09:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:09:48 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:09:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:09:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:10:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:10:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:10:40 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:10:41 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:10:41 --> 404 Page Not Found: admin/Assets/images
ERROR - 2019-07-04 00:10:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:10:53 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:12 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:11:36 --> 404 Page Not Found: admin/Pegawai/assets
ERROR - 2019-07-04 00:12:08 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:12:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:12:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:12:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:12:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:12:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$name_jb D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\delete.php 12
ERROR - 2019-07-04 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$name_jb D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\delete.php 12
ERROR - 2019-07-04 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$name_jb D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\delete.php 12
ERROR - 2019-07-04 00:15:50 --> Severity: Notice --> Undefined property: stdClass::$name_jb D:\xampp\htdocs\web_ambon\application\views\_admin\jabatan\delete.php 12
ERROR - 2019-07-04 00:15:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:15:50 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:16:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:16:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:16:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:16:36 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:17:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:17:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:17:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:17:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:17:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:17:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:20:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:20:07 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:20:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:20:14 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:21:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:21:49 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:22:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:22:54 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:22:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:22:59 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:23:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:23:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:56:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:56:10 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 00:56:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 04:57:07 --> Query error: Unknown column 'desa.slug' in 'field list' - Invalid query: SELECT `posts`.*, `desa`.`desa_id`, `desa`.`nama` as `nama_desa`, `desa`.`slug` as `slug_ds`
FROM `posts`
JOIN `categories` ON `categories`.`id` = `posts`.`category_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `posts`.`category_id` = '1'
AND `posts`.`published` = 'yes'
ORDER BY `posts`.`id` DESC
 LIMIT 3
ERROR - 2019-07-04 05:04:44 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` = 'judul-kedua'
ERROR - 2019-07-04 05:32:52 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` = 'judul-kedua'
ERROR - 2019-07-04 05:32:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-04 05:33:00 --> Query error: Column 'slug' in where clause is ambiguous - Invalid query: SELECT *
FROM `posts`
JOIN `users` ON `users`.`user_id` = `posts`.`user_id`
JOIN `desa` ON `desa`.`desa_id` = `posts`.`desa_id`
WHERE `slug` = 'judul-kedua'
ERROR - 2019-07-04 05:38:30 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-04 05:38:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-04 05:38:30 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-04 05:38:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-04 05:38:31 --> 404 Page Not Found: 
ERROR - 2019-07-04 05:38:31 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-04 05:38:31 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-04 05:41:00 --> Severity: Error --> Call to undefined method Desas_m::get_data() D:\xampp\htdocs\web_ambon\application\controllers\Kegiatan.php 74
ERROR - 2019-07-04 05:42:08 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-04 05:42:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-04 05:42:08 --> Severity: Notice --> Undefined variable: kecamatan D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-04 05:42:08 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-04 05:42:09 --> 404 Page Not Found: 
ERROR - 2019-07-04 05:42:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-04 05:42:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-04 05:42:54 --> 404 Page Not Found: 
ERROR - 2019-07-04 05:43:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-04 05:43:06 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-04 05:43:07 --> 404 Page Not Found: 
ERROR - 2019-07-04 05:43:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\header.php 5
ERROR - 2019-07-04 05:43:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\web_ambon\application\views\_blocks\nav_post.php 20
ERROR - 2019-07-04 05:43:09 --> 404 Page Not Found: 
ERROR - 2019-07-04 05:43:55 --> 404 Page Not Found: 
ERROR - 2019-07-04 05:44:16 --> 404 Page Not Found: 
ERROR - 2019-07-04 05:44:16 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-04 05:44:16 --> 404 Page Not Found: Kegiatan/assets
ERROR - 2019-07-04 05:45:13 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:45:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 05:46:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-04 11:18:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:18:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:20:03 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:20:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:20:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:20:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:21:00 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:21:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:21:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:21:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:21:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-07-04 11:22:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-07-04 11:22:11 --> 404 Page Not Found: Assets/backend
